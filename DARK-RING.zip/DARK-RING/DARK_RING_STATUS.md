# DARK RING (work in progress)

A fork of [DOOM RING](https://github.com/stanleymov/DOOM-RING) (MIT) that targets
**DOOM: The Dark Ages** (Steam app 3017860) instead of DOOM Eternal. Same design: this repo holds
code only; the setup converts assets from the player's own installs of both games.

## Milestone 1: Super Shotgun only

Done in this fork:
- `installer/engine.py`: looks for DOOM The Dark Ages (app 3017860) + ELDEN RING, builds only
  `super_shotgun`, verifies only that.
- `installer/setup.pyw`: text and checks follow the new game.
- `tools/probe_darkages.py`: read-only probe of a real Dark Ages install (see below).

## What the first probe showed (real install, confirmed)

- Archives are `IDCL` containers, version 13 (Eternal's were 12), in `base/`: `common`, `core`, `init`,
  per-level `game/sp/m*/` and `game/dlc/`, each with `_patchN` variants. Bulk data is in 57
  `gameresources_*.streamdb` files (one is 17.7 GB).
- No `oo2core*.dll` next to the exe: Oodle is built into `DOOMTheDarkAges.exe`. Anything that reads the
  streamdb files needs an Oodle library, which cannot be shipped here.
- Sound: `base/sound/soundbanks/pc/SFX.snd` (+ `_patch_1..3`), version 6, and the first entries are
  `RIFF/WAVE` data (not Wwise Vorbis like Eternal's music). `Titan.pck` is a small Wwise bank.
- The game folder already holds Serrat exports (55 `.cast`, 402 `.png`, 5 `.fbx`) plus helper scripts
  from an earlier attempt (`darkring_setup.py`, `scan_archives.py`, `scan_report.txt`, ...).

## Route chosen for milestone 1

Serrat (closed GUI, no CLI) and Valen (GUI only, no Oodle notes) cannot be run silently by a setup.
So milestone 1 reads **Cast exports of the Super Shotgun made from the player's own install** with the
Cast format reader, through the same Skeleton / Meshes / clip calls `convert_weapon.py` already uses
(its "vega" mode was written for Cast exports). The setup still requires Dark Ages and Elden Ring to be
installed (it checks both) and the export comes from that install.

## What the second probe showed (the user's Serrat exports)

- The Super Shotgun is `core/shotguns/double_barrel` (same name as Eternal). Its animation names match
  `convert_weapon.py`'s table: `shoot`, `shoot_reload`, `shootsingle`, `reloadfromempty`, `intro`,
  `idle_pose*`, `dryfire*`, plus meathook layers.
- Clips are split like Eternal's: `<clip>__shotgun_double_barrel.cast` (gun) and `<clip>__doomslayer_1p.cast`
  (arms). For the double barrel only the **gun** clips were exported with data. Its arms clips are
  missing or 176-byte stubs (a 176-byte Cast cannot hold animation data): only `reloadfromempty`
  (1.6 KB) came with some. The generic arms clips in `core/shotgun/` belong to the Combat Shotgun.
- Models exported as Cast: `arms.cast`, `doomslayer_1p_praetor.cast`, `shotgun.cast` (one file holds the
  Combat Shotgun and SSG parts; textures `ssg_upgrade_*` and `combatshotgun_*`).
- `soundmetadata.bin` (1.2 MB) is present for event names.
- Elden Ring is at `I:\...\ELDEN RING`; its game version still has to be checked (needs 1.17.2).

## What the real models showed (ssg_files.zip, checked with tools/vm/cast_read.py)

- Cast reader works on all three models. Two things the spec page got wrong, found on the real files:
  vector types are 0x7632 / 0x7633 / 0x7634, and a node's size counts its own 24-byte header.
- Units are centimetres, up axis `z` (file metadata) = the convention `convert_weapon.py` already uses.
- `shotgun.cast`: 22 bones, 42 meshes (no mesh names; materials tell them apart). Meshes 22-41 are the
  Super Shotgun (`art/weapons/supershotgun/ssg_a`, `ssg_b`, `ssg_shell_a`, `ssg_shellspent_a`, and
  `upgrades/ssg_upgrade_a`); 0-21 are the Combat Shotgun (`combatshotgun*`). Same skeleton for both.
- Arms: `doomslayer_1p_praetor.cast` (97 bones incl. `camera`, `camera_shake`, `weapon_part01_rt/lf`,
  `ik_weapon_rt/lf`, `world_attach_part01_rt/lf`, `propworld_part03_md`; 18 meshes). Eternal's
  `righthandattach` bone does not exist: the gun attach bone has to be read from the animations.
- `tools/vm/cast_compat.py` gives `convert_weapon.py` the `cast` module API on top of the reader
  (skeleton / meshes / materials / curves). Checked: parents precede children, unit quaternions, weights
  sum to 1, all indices in range, for all three models.
- ssg_files.zip had NO animations in it (the first packer looked in one folder only).

## SOUNDS: DONE and tested (ssg_sound.zip from the real install)

- `tools/darkages_events.py` reads `soundmetadata.bin`: 4768 event names (id = Wwise FNV-1 hash of the lower-case
  name) and 3942 events with the sound ids each plays. `tools/data/darkages_ssg_events.json` has the Super
  Shotgun ones (ids only).
- Real install: all 189 `play_plr_wpn_ssg_fire` ids and the reload / click / intro / twirl / modswap ids are in
  `SFX.snd` / `SFX_patch_1.snd`. The Eternal `.snd` index layout (`tools/doom_snd.py`) works unchanged.
- Each sound is RIFF/WAVE with codec 0x3041 = Wwise Opus, stereo 48 kHz. vgmstream-cli decodes it (8 real
  samples decoded: fire 0.33 s, reload 0.66 s, intro 3.7 s ...).
- `tools/darkages_sounds.py` -> `doom_audio/ssg_fire|ssg_reload|ssg_reload_click|ssg_intro|...` as 48 kHz stereo
  WAV (what `doomslayer.dll` loads). The fire event also lists non-fire sounds (the twirl), so it keeps the
  variants closest to the median length. Tested end to end on a synthetic bank built from the real metadata and
  the 8 real samples. NOT yet heard in game; which of the 189 variants sound best is unchecked.
- `installer/engine.py` runs it (downloads vgmstream-win64 from GitHub like it does ffmpeg for Eternal).

## MODEL / ARMS: DONE (converter runs on the real exports)

- Correction: the Super Shotgun is NOT a separate model. `shotgun_1p.cast` holds both shotguns; the game hides meshes
  to switch modes. Meshes 22-41 are the Super Shotgun (materials `ssg*`), 0-21 the Combat Shotgun (hidden).
- `tools/vm/convert_weapon.py` has a `darkages` source (cast_compat). Clips from `core/shotgun_spear/`: idle, bringup,
  bringdown, dryfire, fire (`shoot_super_delay`), fire_last, reload (`reload_from_empty_super`). Arms = first 6 meshes
  of `doomslayer_1p_praetor.cast`. Gun attaches to arms bone `weapon_part01_rt` (override DOOMRING_DA_ATTACH).
- Tested on the real files: 26 meshes, 7 clips; gun lands forward/right/below the camera. Not yet seen in game.
- Textures: none found next to the exports yet (0 copied); muzzle/tags not available (no md6def decls).

## NOT done yet

1. Export the SSG model (search `double_barrel` under Models in Serrat). Then point `convert_weapon.py` at
   the Dark Ages files / bone names (`camera`, a gun attach bone, SSG mesh filter).
2. Decide how the arms are posed (needs the SSG arms clips or an IK rule).
3. Rust side (`doomslayer/`): still the 8-weapon Eternal arsenal; must tolerate missing HUD / music
   folders; the converted gun plugs into the `SUPER_SHOTGUN` slot.
4. Needs a Windows MSVC build and a test on a PC with both games.

## Steps for you

1. Serrat: Models, search `double_barrel`, export as Cast (with textures if it asks).
2. `tools/pack_ssg_files.py` (new version): F5 in IDLE; it lists what it found; send `ssg_files.zip`.

## SHIELD (blocking only)
- Setup bakes `shield` = Super Shotgun + Shield Saw in one model (shield_1p.cast + core/shotgun_shield clips; 95 weighted bones, the renderer's limit).
- T equips / removes the Shield: the Super Shotgun stays in hand and fires as usual, the Meathook is off while it is equipped. Hold the weapon-mod button (right mouse) to put the guard up (the gun lowers). Settings: `shield_*` in doomslayer.toml, key `[keys] shield`.
- A hit taken with the guard up and a hostile in front is reduced by `shield_block`, shoves the player away (`shield_push`) and shakes yaw/pitch/roll (`shield_shake*`).

## LANDING
- No fall damage (`no_fall_damage`), and a landing after `land_min_air` s in the air sends a shockwave (`land_*` settings: radius, damage per second of air, camera shake). Guard release no longer blocks firing.
