"""DOOM RING setup engine: finds the games through Steam, checks them, and builds the mod's Doom content
from the player's own DOOM The Dark Ages install with the bundled converters (setup GUI: setup.pyw).

Package layout (installer/build_package.py makes it):
    Setup DOOM RING.exe     launcher -> runtime\\pythonw.exe setup\\setup.pyw
    runtime\\               Python 3.12 + numpy / scipy / Pillow / tkinter
    setup\\                 this engine, the GUI, tools\\ (converters), data\\
    bin\\                   samuel-cli.exe (GPL-3), ww2ogg.exe + codebooks (BSD-3), licenses
    payload\\               the mod itself (DLL, settings, me3, launcher .bat, README, fonts)
"""
import ctypes
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ELDEN_RING_APP = "1245620"
DOOM_DARK_AGES_APP = "3017860"
NO_WINDOW = 0x08000000
# ffmpeg (GPL) when the PC has none: BtbN's Windows build, downloaded by the setup - not shipped by us
FFMPEG_URL = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
# vgmstream-cli (ISC licence) decodes DOOM The Dark Ages' Wwise Opus sounds: downloaded by the setup, not shipped by us
VGMSTREAM_URL = "https://github.com/vgmstream/vgmstream-releases/releases/download/nightly/vgmstream-win64.zip"

HERE = Path(__file__).resolve().parent            # <package>/setup
PACKAGE = HERE.parent
TOOLS = HERE / "tools"
BIN = PACKAGE / "bin"
PAYLOAD = PACKAGE / "payload"
OBSOLETE = ("license/fromsoftware-rs-LICENSE-MIT.txt", "license/fromsoftware-rs-LICENSE-APACHE.txt")
# (development: run from the repo - installer/engine.py with tools/ beside it)
if not TOOLS.exists():
    TOOLS = HERE.parent / "tools"
WEAPONS = ["super_shotgun", "flail", "fists", "shield"]   # the Super Shotgun, the Flail melee tool, the Shield
# What DOOM The Dark Ages must have (names confirmed from a real install by tools/probe_darkages.py):
# the exe, the core / common / init archives (IDCL container, version 13) and the PC sound bank.
DOOM_FILES = ["DOOMTheDarkAges.exe", "base/common.resources", "base/core.resources", "base/init.resources",
              "base/sound/soundbanks/pc/SFX.snd"]


# ------------------------------------------------------------------------------------- Steam

def steam_root():
    try:
        import winreg
        for hive, key, val in ((winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
                               (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
                               (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam", "InstallPath")):
            try:
                with winreg.OpenKey(hive, key) as k:
                    p = Path(winreg.QueryValueEx(k, val)[0])
                    if p.exists():
                        return p
            except OSError:
                pass
    except ImportError:
        pass
    p = Path("C:/Program Files (x86)/Steam")
    return p if p.exists() else None


def steam_libraries():
    root = steam_root()
    libs = []
    if root:
        libs.append(root)
        vdf = root / "steamapps" / "libraryfolders.vdf"
        if vdf.exists():
            for m in re.finditer(r'"path"\s+"([^"]+)"', vdf.read_text(encoding="utf-8", errors="ignore")):
                p = Path(m.group(1).replace("\\\\", "\\"))
                if p not in libs:
                    libs.append(p)
    return [p for p in libs if p.exists()]


def find_app(app_id):
    """The game's install folder from Steam's manifests, or None."""
    for lib in steam_libraries():
        acf = lib / "steamapps" / f"appmanifest_{app_id}.acf"
        if acf.exists():
            m = re.search(r'"installdir"\s+"([^"]+)"', acf.read_text(encoding="utf-8", errors="ignore"))
            if m:
                p = lib / "steamapps" / "common" / m.group(1)
                if p.exists():
                    # (the real folder name casing - Steam's library file stores the path lower case)
                    return Path(os.path.realpath(p))
    return None


def file_version(path):
    """'2.7.2.0'-style file version of an exe (Windows), or None."""
    try:
        size = ctypes.windll.version.GetFileVersionInfoSizeW(str(path), None)
        if not size:
            return None
        buf = ctypes.create_string_buffer(size)
        ctypes.windll.version.GetFileVersionInfoW(str(path), 0, size, buf)
        ptr, n = ctypes.c_void_p(), ctypes.c_uint()
        ctypes.windll.version.VerQueryValueW(buf, "\\", ctypes.byref(ptr), ctypes.byref(n))
        ms, ls = ctypes.cast(ptr.value + 8, ctypes.POINTER(ctypes.c_uint32 * 2)).contents
        return f"{ms >> 16}.{ms & 0xFFFF}.{ls >> 16}.{ls & 0xFFFF}"
    except Exception:
        return None


def check_elden_ring(path):
    """(ok, message)"""
    if path is None:
        return False, ("ELDEN RING was not found. Install it through Steam (the base game is enough), "
                       "then press Check again - or point to its folder with Browse.")
    exe = Path(path) / "Game" / "eldenring.exe"
    if not exe.exists():
        return False, f"No Game\\eldenring.exe in {path}. Is this the ELDEN RING folder?"
    ver = file_version(exe)
    msg = f"Found: {path}" + (f"  (version {ver})" if ver else "")
    if ver and not ver.startswith("2.7.2"):
        msg += "\nNote: DOOM RING was made for ELDEN RING 1.17.2 (app 2.7.2). Other versions may not work."
    return True, msg


def check_doom(path):
    """DOOM The Dark Ages: the exe and the archives the Super Shotgun is built from."""
    if path is None:
        return False, ("DOOM The Dark Ages was not found. The mod's gun, sounds and animations are made from YOUR "
                       "copy of the game - install it through Steam, then press Check again.")
    missing = [f for f in DOOM_FILES if not (Path(path) / f).exists()]
    if missing:
        return False, f"DOOM The Dark Ages at {path} is missing files ({missing[0]} ...). Let Steam verify the game files."
    return True, f"Found: {path}"


def setup_version():
    """This setup's version.json: {"version": "1.1", "content": 1}."""
    v = json.loads((HERE / "version.json").read_text(encoding="utf-8"))
    return {"version": str(v["version"]), "content": int(v["content"])}


INSTALLED_FILE = "doomring_version.json"


def installed_version(target):
    """What is already in `target`: {"version", "content"} or None (nothing usable - a full install).
    A complete 1.0 install has no version file; it is recognised by its converted DOOM files."""
    t = Path(target)
    f = t / INSTALLED_FILE
    if f.exists():
        try:
            v = json.loads(f.read_text(encoding="utf-8"))
            return {"version": str(v["version"]), "content": int(v["content"])}
        except (ValueError, KeyError, OSError):
            return None
    natives = t / "game" / "natives"
    if (natives / "doomslayer.dll").exists() and all(
            (natives / "doom_vm" / w / "model.bin").exists() for w in WEAPONS):
        return {"version": "0.1", "content": 1}
    return None


def free_gb(path):
    p = Path(path)
    while not p.exists() and p.parent != p:
        p = p.parent
    return shutil.disk_usage(p).free / 1e9


# ------------------------------------------------------------------------------------- install

class Cancelled(Exception):
    pass


class Installer:
    """Runs the steps in a thread; `on_progress(fraction, step text)` and `on_log(line)` are called
    from that thread (the GUI marshals them)."""

    def __init__(self, doom, target, on_progress, on_log, workers=None):
        # (None: DOOM The Dark Ages isn't installed - fine for a mod-files update, see steps())
        self.doom = Path(doom) if doom else None
        self.target = Path(target)
        self.version = setup_version()
        # an update over the same converted content only copies the new mod files (seconds); a new
        # content number (converters / sound lists changed) or no usable install rebuilds everything
        old = installed_version(self.target)
        self.update_from = old["version"] if old else None
        self.quick = bool(old and old["content"] == self.version["content"])
        self.natives = self.target / "game" / "natives"
        self.work = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "DRSetup"
        self.on_progress = on_progress
        self.on_log = on_log
        self.cancelled = False
        self.procs = []
        self.workers = workers or max(1, min(4, (os.cpu_count() or 2) // 2))
        self.log_file = None
        self.ffmpeg = None
        self.vgmstream = None
        self.pylibs = None
        self._base, self._span = 0.0, 0.0

    # -- helpers
    def log(self, line):
        line = line.rstrip()
        if self.log_file:
            self.log_file.write(line + "\n")
            self.log_file.flush()
        self.on_log(line)

    def python(self):
        exe = Path(sys.executable)
        con = exe.with_name("python.exe")
        return str(con if con.exists() else exe)

    def env(self):
        e = dict(os.environ)
        e.update({
            "DOOMRING_DOOM": str(self.doom or ""),
            "DOOMRING_WORK": str(self.work),
            "DOOMRING_OUT": str(self.natives),
            "DOOMRING_VM_OUT": str(self.natives / "doom_vm"),
            "DOOMRING_VM_SOURCE": "darkages",
            "DOOMRING_DA_EXPORT": str(Path(self.doom) / "exported_files") if self.doom else "",
            "DOOMRING_SAMUEL": str(BIN / "samuel-cli.exe") if (BIN / "samuel-cli.exe").exists() else e.get("DOOMRING_SAMUEL", ""),
            "DOOMRING_WW2OGG": str(BIN / "ww2ogg.exe") if (BIN / "ww2ogg.exe").exists() else e.get("DOOMRING_WW2OGG", ""),
            "PYTHONUNBUFFERED": "1",
            "PYTHONIOENCODING": "utf-8",
            # (the bundled Python only: never a player's own Python settings or packages)
            "PYTHONNOUSERSITE": "1",
        })
        for k in ("PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP"):
            e.pop(k, None)
        if self.ffmpeg:
            e["DOOMRING_FFMPEG"] = str(self.ffmpeg)
        if self.pylibs:
            e["PYTHONPATH"] = str(self.pylibs)
        if self.vgmstream:
            e["DOOMRING_VGMSTREAM"] = str(self.vgmstream)
        return {k: v for k, v in e.items() if v != ""}

    def run(self, script, *args):
        if self.cancelled:
            raise Cancelled()
        cmd = [self.python(), str(TOOLS / script), *args]
        self.log(f"> {script} {' '.join(args)}")
        p = subprocess.Popen(cmd, cwd=str(TOOLS), env=self.env(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
        self.procs.append(p)
        for line in p.stdout:
            self.log("  " + line.rstrip())
            if self.cancelled:
                p.kill()
        p.wait()
        self.procs.remove(p)
        if self.cancelled:
            raise Cancelled()
        if p.returncode != 0:
            raise RuntimeError(f"{script} {' '.join(args)} failed (exit {p.returncode}) - see the log")

    def sub_progress(self, frac, text):
        """Progress inside the running step (0..1 of its share of the bar)."""
        self.on_progress(self._base + self._span * min(max(frac, 0.0), 1.0), text)

    def cancel(self):
        self.cancelled = True
        for p in list(self.procs):
            try:
                p.kill()
            except OSError:
                pass

    # -- steps (weights = rough share of the time)
    def steps(self):
        if self.quick:
            return [
                (1, "Updating the mod files", self.copy_payload),
                (1, "Checking the result", self.verify),
            ]
        # First milestone: only the Super Shotgun is built (model, animations, textures). Sounds, music
        # and the HUD come back one by one once their Dark Ages sources are worked out.
        return [
            (2, "Copying the mod files", self.copy_payload),
            (4, "Checking Python packages (numpy)", self.get_pylibs),
            (4, "Checking for vgmstream (audio decoder)", self.get_vgmstream),
            (10, "Super Shotgun sounds", lambda: self.run("darkages_sounds.py")),
            (80, "Super Shotgun: model, arms and animations", self.weapons),
            (4, "Checking the result", self.verify),
        ]

    def copy_payload(self):
        if not PAYLOAD.exists():
            raise RuntimeError(f"payload folder missing: {PAYLOAD}")
        self.target.mkdir(parents=True, exist_ok=True)
        for src in PAYLOAD.rglob("*"):
            dst = self.target / src.relative_to(PAYLOAD)
            if src.is_dir():
                dst.mkdir(parents=True, exist_ok=True)
            elif not (dst.exists() and dst.name in ("doomslayer.toml", "erfps2.toml")):
                # (a reinstall keeps the player's settings)
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
        # files an older version installed that this one replaced (1.3: fromsoftware-rs's licences
        # are now the NON-AI variants)
        for rel in OBSOLETE:
            (self.target / rel).unlink(missing_ok=True)
        self.log(f"mod files -> {self.target}")

    def get_ffmpeg(self):
        """ffmpeg for the audio steps: bundled, on the PC already, or downloaded once (~130 MB)."""
        for c in (BIN / "ffmpeg.exe", self.work / "ffmpeg" / "ffmpeg.exe"):
            if c.exists():
                self.ffmpeg = c
                break
        else:
            found = shutil.which("ffmpeg")
            if found:
                self.ffmpeg = Path(found)
        if self.ffmpeg:
            self.log(f"ffmpeg: {self.ffmpeg}")
            return
        import urllib.request
        import zipfile
        zpath = self.work / "ffmpeg.zip"
        self.log(f"downloading ffmpeg from {FFMPEG_URL}")
        with urllib.request.urlopen(FFMPEG_URL, timeout=60) as r, open(zpath, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            got = 0
            while True:
                if self.cancelled:
                    raise Cancelled()
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if total:
                    self.sub_progress(got / total, f"Downloading ffmpeg (free audio tool): {got * 100 // total}%")
        with zipfile.ZipFile(zpath) as z:
            name = next(n for n in z.namelist() if n.endswith("bin/ffmpeg.exe"))
            (self.work / "ffmpeg").mkdir(exist_ok=True)
            with z.open(name) as src, open(self.work / "ffmpeg" / "ffmpeg.exe", "wb") as dst:
                shutil.copyfileobj(src, dst)
        zpath.unlink()
        self.ffmpeg = self.work / "ffmpeg" / "ffmpeg.exe"
        self.log(f"ffmpeg: {self.ffmpeg}")

    def get_pylibs(self):
        """The converters need numpy. Setup runs on the player's own Python, so install numpy once into a private
        folder (DRSetup\\pylibs) if the Python cannot import it."""
        probe = subprocess.run([self.python(), "-c", "import numpy"], capture_output=True, creationflags=NO_WINDOW)
        if probe.returncode == 0:
            return
        lib = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "DRSetup" / "pylibs"
        lib.mkdir(parents=True, exist_ok=True)
        self.log("numpy not found: installing it with pip (needs internet, about 20 MB)")
        r = subprocess.run([self.python(), "-m", "pip", "install", "--upgrade", "--target", str(lib), "numpy"],
                           capture_output=True, text=True, creationflags=NO_WINDOW)
        if r.returncode != 0:
            raise RuntimeError("could not install numpy: " + (r.stdout + r.stderr).strip()[-400:])
        self.pylibs = lib

    def get_vgmstream(self):
        """vgmstream-cli for the sound step: bundled, on the PC already, or downloaded once (~4 MB)."""
        for c in (BIN / "vgmstream-cli.exe", self.work / "vgmstream" / "vgmstream-cli.exe"):
            if c.exists():
                self.vgmstream = c
                break
        else:
            found = shutil.which("vgmstream-cli")
            if found:
                self.vgmstream = Path(found)
        if self.vgmstream:
            self.log(f"vgmstream: {self.vgmstream}")
            return
        import urllib.request
        import zipfile
        zpath = self.work / "vgmstream.zip"
        self.log(f"downloading vgmstream from {VGMSTREAM_URL}")
        with urllib.request.urlopen(VGMSTREAM_URL, timeout=60) as r, open(zpath, "wb") as f:
            shutil.copyfileobj(r, f)
        dest = self.work / "vgmstream"
        dest.mkdir(exist_ok=True)
        with zipfile.ZipFile(zpath) as z:
            for name in z.namelist():
                # (flat: the exe and its DLLs must sit together)
                if name.endswith("/") or "/" in name.strip("/"):
                    continue
                with z.open(name) as src, open(dest / name, "wb") as dst:
                    shutil.copyfileobj(src, dst)
        zpath.unlink()
        if not (dest / "vgmstream-cli.exe").exists():
            raise RuntimeError("the vgmstream download has no vgmstream-cli.exe")
        self.vgmstream = dest / "vgmstream-cli.exe"
        self.log(f"vgmstream: {self.vgmstream}")

    def music(self):
        self.run("doom_music_bank.py")
        self.run("convert_music.py", "--suites")

    def hud(self):
        self.run("convert_hud_textures.py")
        self.run("convert_hud_textures.py", "--settings")
        self.run("convert_hud_textures.py", "--pad")
        self.run("convert_ammo_icons.py")
        self.run("convert_reticles.py")
        self.run("convert_ui.py")
        self.run("convert_font.py")

    def weapons(self):
        exp = Path(self.doom) / "exported_files" / "models" / "md6" / "weapons" / "shotgun" / "base" / "assets" / "mesh" / "shotgun_1p.cast"
        if not exp.exists():
            raise RuntimeError("Super Shotgun export not found: export shotgun_1p, doomslayer_1p_praetor and the shotgun_spear animations with Serrat (Cast) into the DOOM The Dark Ages folder (exported_files). See DARK_RING_STATUS.md.")
        fl = exp.parents[4] / "flail" / "base" / "assets" / "mesh" / "flail_1p.cast"
        if not fl.exists():
            raise RuntimeError("Flail export not found: export flail_1p (Cast) and the melee_strikes melee_flail_* animations with Serrat into the DOOM The Dark Ages folder (exported_files).")
        sh = exp.parents[4] / "shield" / "base" / "assets" / "mesh" / "shield_1p.cast"
        if not sh.exists():
            raise RuntimeError("Shield export not found: export shield_1p (Cast) and the whole core/shotgun_shield animation folder (arms, shotgun and shield clips) with Serrat into the DOOM The Dark Ages folder (exported_files).")
        done = []
        errors = []

        def one(w):
            try:
                self.run("vm/convert_weapon.py", w)
                done.append(w)
                self.sub_progress(len(done) / len(WEAPONS), f"Guns, arms and animations: {len(done)} of {len(WEAPONS)} done")
            except Exception as e:  # noqa: BLE001
                errors.append(f"{w}: {e}")

        with ThreadPoolExecutor(self.workers) as pool:
            list(pool.map(one, WEAPONS))
        if self.cancelled:
            raise Cancelled()
        if errors:
            raise RuntimeError("; ".join(errors))

    def verify(self):
        bad = [f"doom_vm/{w} missing" for w in WEAPONS if not (self.natives / "doom_vm" / w / "model.bin").exists()]
        for ev in ("ssg_fire", "ssg_reload", "flail_swing", "flail_impact"):
            n = len(list((self.natives / "doom_audio" / ev).glob("*.wav")))
            self.log(f"doom_audio/{ev}: {n} files")
            if n == 0:
                bad.append(f"doom_audio/{ev} has no sounds")
        if bad:
            raise RuntimeError("incomplete: " + ", ".join(bad))

    # -- main
    def install(self):
        self.work.mkdir(parents=True, exist_ok=True)
        log_path = self.target / "setup_log.txt"
        self.target.mkdir(parents=True, exist_ok=True)
        self.log_file = open(log_path, "w", encoding="utf-8")
        self.log(f"DOOM RING {self.version['version']} setup {time.strftime('%Y-%m-%d %H:%M')}: "
                 f"DOOM The Dark Ages {self.doom or '(not installed: update only)'} -> {self.target}")
        if self.update_from:
            self.log(f"update from {self.update_from}" + (" (mod files only)" if self.quick else " (DOOM content rebuilt)"))
        if self.doom is None and not self.quick:
            raise RuntimeError("DOOM The Dark Ages is needed to build DOOM RING's DOOM files - install it through Steam")
        steps = self.steps()
        total = sum(w for w, _, _ in steps)
        done = 0
        t0 = time.time()
        try:
            for weight, text, fn in steps:
                self._base, self._span = done / total, weight / total
                self.on_progress(done / total, text)
                s = time.time()
                fn()
                self.log(f"[{text}: {time.time() - s:.0f} s]")
                done += weight
            (self.target / INSTALLED_FILE).write_text(json.dumps(self.version), encoding="utf-8")
            self.on_progress(1.0, "Done")
            self.log(f"finished in {(time.time() - t0) / 60:.1f} min")
            shutil.rmtree(self.work, ignore_errors=True)
        finally:
            self.log_file.close()
            self.log_file = None
        return log_path


def desktop_shortcut(target):
    """A desktop shortcut to the game's launcher (.lnk through Windows Script Host)."""
    bat = Path(target) / "Play DOOM RING.bat"
    icon = Path(target) / "doomring.ico"

    def q(p):  # PowerShell single-quoted string
        return "'" + str(p).replace("'", "''") + "'"

    # (Windows' own Desktop folder - it is often moved to OneDrive, not USERPROFILE\Desktop)
    ps = ("$d=[Environment]::GetFolderPath('Desktop');$l=Join-Path $d 'DOOM RING.lnk';"
          "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($l);"
          f"$s.TargetPath={q(bat)};$s.WorkingDirectory={q(bat.parent)};"
          + (f"$s.IconLocation={q(icon)};" if icon.exists() else "") + "$s.Save();Write-Output $l")
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], creationflags=NO_WINDOW, capture_output=True,
                       text=True)
    lnk = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
    return bool(lnk) and Path(lnk).exists()


def start_thread(fn):
    t = threading.Thread(target=fn, daemon=True)
    t.start()
    return t
