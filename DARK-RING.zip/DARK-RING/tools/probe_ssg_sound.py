"""Check DOOM The Dark Ages' sound banks for the Super Shotgun sounds. In IDLE: open this file, press F5.

Reads only the small index tables of SFX.snd and its patches (not the 2.8 GB of audio), looks for the sound ids
of the Super Shotgun events, and saves up to 8 small sample sounds. Writes  ssg_sound.zip  next to this script:
send that zip. Nothing in the game folder is changed.
"""
import collections
import json
import os
import struct
import sys
import zipfile

CANDIDATES = [r"H:\SteamLibrary\steamapps\common\DOOMTheDarkAges",
              r"C:\Program Files (x86)\Steam\steamapps\common\DOOMTheDarkAges"]
EVENTS = json.loads('{"play_plr_wpn_ssg_fire": [37681421, 64904421, 169589406, 269924874, 323670183, 398600974, 427121600, 477924496, 485622972, 498971262, 502336042, 505446082, 573854398, 687181135, 712360210, 714277084, 832940949, 863059000, 871389866, 967127526, 1061536488, 677816432, 736485108, 768986536, 1060600025, 348505070, 724370439, 785257014, 963975512, 232598528, 426228041, 616879661, 796168130, 98712093, 949342251, 1058757232, 1073425464, 433614419, 523821832, 763234524, 796613503, 240471639, 828779237, 987074446, 1022552096, 279503768, 381046885, 527177310, 1067872426, 643040106, 665577670, 798157122, 1051859563, 8606780, 409315646, 443399963, 1053783593, 517490525, 803198842, 811769238, 824573608, 50099076, 157784423, 491566832, 637328155, 173427569, 257979291, 505294736, 962005428, 12792821, 717077644, 881022502, 925063646, 169437197, 454771681, 521743671, 1062357881, 321863814, 536458357, 538304469, 564272328, 183464825, 362827216, 779528570, 836640162, 159945338, 161378600, 345921357, 569410528, 279488788, 364313170, 933359372, 954168463, 263886997, 484886115, 822080456, 1005793130, 16640154, 107993231, 200563523, 853230608, 143996903, 513913362, 864045494, 887130105, 470124739, 498218879, 550930778, 632031508, 15975036, 304687501, 819253432, 958849120, 308118548, 611844784, 832159313, 868916034, 429127560, 458531011, 553255250, 729144932, 132538586, 486119059, 671533861, 858306891, 228079403, 415623020, 912514692, 1003604499, 18051793, 309261164, 969318145, 1072425763, 638300298, 787625040, 790531243, 970593084, 702326322, 787107672, 912285619, 977405082, 254126821, 372282976, 583166386, 949467429, 208129601, 406686641, 749044131, 858392263, 120947985, 276358558, 497509051, 792500593, 217130484, 423964459, 532246059, 1020226695, 197187752, 284809631, 488588674, 996167768, 142041928, 486341685, 591848688, 910802152, 161141153, 238105052, 284323335, 338674108, 560653957, 638621746, 758640629, 793437889, 223406627, 476969022, 705785840, 777735246, 97235035, 262072388, 368409127, 788121257, 277195628, 661425330, 738125059, 783124868, 213387260, 354605145, 631446648, 949006463], "play_plr_wpn_ssg_intro": [988205988], "play_plr_wpn_ssg_intro_grab": [958931461], "play_plr_wpn_ssg_last_shot_twirl": [573854398], "play_plr_wpn_ssg_modswap": [899547676], "play_plr_wpn_ssg_reload": [759874932, 774640724, 831539624], "play_plr_wpn_ssg_reload_click": [174463564, 492607010, 999319334]}')
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "ssg_sound.zip")
LOG = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s)
    LOG.append(s)


def find_game():
    for c in [os.path.dirname(HERE), *CANDIDATES]:
        if os.path.exists(os.path.join(c, "DOOMTheDarkAges.exe")):
            return c
    p = input("Path to your DOOMTheDarkAges folder: ").strip().strip('"')
    if not os.path.exists(os.path.join(p, "DOOMTheDarkAges.exe")):
        sys.exit("DOOMTheDarkAges.exe not found in that folder.")
    return p


def index(path):
    """Records as Eternal's .snd files lay them out: u32 version, u32 info size, u32 header size, <header> bytes,
    then 32-byte records (8 bytes, u32 id, u32 size, u32 offset, u32 decoded size, u16 format, 6 bytes)."""
    with open(path, "rb") as f:
        ver, info, hdr = struct.unpack("<3I", f.read(12))
        n = (info - hdr) // 32
        log(f"  {os.path.basename(path)}: version {ver}, info {info:,}, header {hdr:,}, {n:,} records of 32 bytes")
        if not 0 < n < 5_000_000:
            f.seek(0)
            log("  !! unexpected sizes; first 64 bytes:", f.read(64).hex(" "))
            return {}, None
        f.seek(12 + hdr)
        raw = f.read(n * 32)
    recs = {}
    for k in range(n):
        sid, size, off, dec, fmt = struct.unpack_from("<IIIIH", raw, k * 32 + 8)
        if size:
            recs[sid] = (off, size, fmt, dec)
    return recs, raw


def main():
    game = find_game()
    bank = os.path.join(game, "base", "sound", "soundbanks", "pc")
    files = sorted(f for f in os.listdir(bank) if f.lower().startswith("sfx") and f.lower().endswith(".snd"))
    log("Banks:", files)
    all_recs = {}
    for fn in files:
        try:
            recs, raw = index(os.path.join(bank, fn))
        except Exception as e:  # noqa: BLE001
            log("  !!", fn, "failed:", repr(e))
            continue
        fmts = collections.Counter(r[2] for r in recs.values())
        log("    usable records:", len(recs), " formats:", dict(fmts))
        for sid, r in recs.items():
            all_recs[sid] = (fn, *r)
    log()
    samples = []
    for ev, ids in EVENTS.items():
        found = [i for i in ids if i in all_recs]
        log(f"{ev}: {len(found)} of {len(ids)} sound ids found in the banks")
        for i in found[:2 if "fire" in ev else 1]:
            fn, off, size, fmt, dec = all_recs[i]
            with open(os.path.join(bank, fn), "rb") as f:
                f.seek(off)
                data = f.read(min(size, 400_000))
            log(f"    id {i}: {fn} offset {off:,} size {size:,} decoded {dec:,} format {fmt}  starts {data[:16].hex(' ')}")
            samples.append((f"{ev}_{i}_fmt{fmt}.bin", data))
    if not any(any(i in all_recs for i in ids) for ids in EVENTS.values()):
        log("\nNo sound id matched. Searching the banks' index area for the first fire id to see the real layout...")
        want = struct.pack("<I", EVENTS["play_plr_wpn_ssg_fire"][0])
        for fn in files[:2]:
            with open(os.path.join(bank, fn), "rb") as f:
                ver, info, hdr = struct.unpack("<3I", f.read(12))
                f.seek(12 + hdr)
                chunk = f.read(min(info - hdr, 64_000_000))
            p = chunk.find(want)
            log(f"  {fn}: id bytes {'found at ' + str(p) if p >= 0 else 'not found'}")
            if p >= 0:
                log("    context:", chunk[max(0, p - 32):p + 48].hex(" "))
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("ssg_sound_report.txt", "\n".join(LOG))
        for name, data in samples:
            z.writestr("samples/" + name, data)
    log(f"\nWrote {OUT} ({os.path.getsize(OUT) / 1e6:.1f} MB). Send that zip.")


main()
