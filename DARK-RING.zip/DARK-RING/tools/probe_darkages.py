"""Probe a DOOM The Dark Ages install and write a report of what is in it.

DARK RING's converters need to know the exact archive names, container headers and sound bank
files of the player's own install. Run this once; it only READS files and writes one text report.

    python tools/probe_darkages.py "C:/Program Files (x86)/Steam/steamapps/common/DOOMTheDarkAges"

With no argument it looks the game up through Steam's library folders. The report
(darkages_probe.txt, next to this script's working directory) contains file names, sizes, the
first 32 bytes of each archive and Oodle / Wwise hints. It contains no game data.
"""
import os
import re
import sys
from pathlib import Path

APP_ID = "3017860"
ARCHIVE_EXT = {".resources", ".streamdb", ".index", ".snd", ".pck", ".bnk", ".wem", ".dll", ".exe"}


def steam_libraries():
    roots = []
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as k:
            roots.append(Path(winreg.QueryValueEx(k, "SteamPath")[0]))
    except Exception:  # noqa: BLE001 (not Windows / no registry key)
        pass
    roots.append(Path("C:/Program Files (x86)/Steam"))
    libs = []
    for r in roots:
        vdf = r / "steamapps" / "libraryfolders.vdf"
        if r.exists() and r not in libs:
            libs.append(r)
        if vdf.exists():
            for m in re.finditer(r'"path"\s+"([^"]+)"', vdf.read_text(encoding="utf-8", errors="ignore")):
                p = Path(m.group(1).replace("\\\\", "\\"))
                if p.exists() and p not in libs:
                    libs.append(p)
    return libs


def find_install():
    for lib in steam_libraries():
        acf = lib / "steamapps" / f"appmanifest_{APP_ID}.acf"
        if acf.exists():
            m = re.search(r'"installdir"\s+"([^"]+)"', acf.read_text(encoding="utf-8", errors="ignore"))
            if m and (lib / "steamapps" / "common" / m.group(1)).exists():
                return lib / "steamapps" / "common" / m.group(1)
    return None


def head(path, n=32):
    with open(path, "rb") as f:
        b = f.read(n)
    return b.hex(" "), "".join(chr(c) if 32 <= c < 127 else "." for c in b)


EXPORT_EXT = {".cast", ".fbx", ".decl", ".json", ".cfg", ".ini", ".txt", ".bin", ".py", ".obj", ".smd", ".dds", ".tga"}


def exports_report(root):
    """Names (no contents) of exported / helper files inside the game folder, grouped by folder. PNGs are
    counted per folder with a sample of their names."""
    lines = ["== exported and helper files (names only)"]
    by_dir = {}
    for p in sorted(root.rglob("*")):
        if p.is_file() and (p.suffix.lower() in EXPORT_EXT or p.suffix.lower() == ".png"):
            by_dir.setdefault(p.parent.relative_to(root).as_posix() or ".", []).append(p)
    for d, files in by_dir.items():
        pngs = [f for f in files if f.suffix.lower() == ".png"]
        others = [f for f in files if f.suffix.lower() != ".png"]
        lines.append(f"  [{d}]  {len(others)} files, {len(pngs)} png")
        for f in others:
            try:
                hx, _ = head(f, 16)
            except OSError:
                hx = "?"
            lines.append(f"      {f.name}  {f.stat().st_size:,} B  {hx}")
        for f in pngs[:60]:
            lines.append(f"      {f.name}")
        if len(pngs) > 60:
            lines.append(f"      ... {len(pngs) - 60} more png")
    return lines


def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 and not sys.argv[1].startswith("--") else find_install()
    if not root or not root.exists():
        sys.exit("DOOM The Dark Ages was not found. Pass its folder as the argument.")
    lines = [f"DOOM The Dark Ages probe: {root}", ""]
    top = sorted(p for p in root.iterdir())
    lines.append("== top level")
    for p in top:
        lines.append(f"  {'<dir>' if p.is_dir() else f'{p.stat().st_size:>14,}'}  {p.name}")
    lines.append("")
    lines.append("== archives and sound files (size, first 32 bytes hex | ascii)")
    count = {}
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        ext = p.suffix.lower()
        count[ext] = count.get(ext, 0) + 1
        if ext in ARCHIVE_EXT:
            try:
                hx, asc = head(p)
            except OSError as e:
                hx, asc = f"unreadable: {e}", ""
            lines.append(f"  {p.relative_to(root).as_posix()}  {p.stat().st_size:,} B")
            lines.append(f"      {hx} | {asc}")
    lines.append("")
    lines.append("== file counts by extension")
    for ext, n in sorted(count.items(), key=lambda kv: -kv[1]):
        lines.append(f"  {ext or '(none)':>12}  {n}")
    lines.append("")
    lines.append("== hints")
    lines.append(f"  oodle dll present: {any(root.glob('oo2core*.dll'))}")
    lines.append(f"  .resources archives: {count.get('.resources', 0)}   .streamdb: {count.get('.streamdb', 0)}")
    lines.append(f"  Wwise-style files (.pck/.bnk/.wem/.snd): "
                 f"{sum(count.get(e, 0) for e in ('.pck', '.bnk', '.wem', '.snd'))}")
    if "--exports" in sys.argv:
        lines.append("")
        lines.extend(exports_report(root))
    out = Path.cwd() / ("darkages_exports.txt" if "--exports" in sys.argv else "darkages_probe.txt")
    out.write_text("\n".join(lines), encoding="utf-8")
    print(f"wrote {out} ({len(lines)} lines)")


if __name__ == "__main__":
    main()
