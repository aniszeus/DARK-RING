"""One-click version of `probe_darkages.py --exports` for IDLE: open this file and press F5.

Keep it in the same folder as probe_darkages.py. It finds DOOM The Dark Ages through Steam and writes
darkages_exports.txt (names and sizes only, no game data) into the folder this file is in.
"""
import os
import sys

here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, here)
os.chdir(here)
sys.argv = [sys.argv[0], "--exports"]

import probe_darkages  # noqa: E402

probe_darkages.main()
print("Done. Send the file darkages_exports.txt from:", here)
