"""Super Shotgun sounds from the player's own DOOM The Dark Ages install -> doom_audio/<event>/<n>.wav

How (all checked on a real install):
  1. base/sound/soundbanks/pc/soundmetadata.bin says which sound ids each Wwise event plays
     (tools/darkages_events.py).
  2. SFX.snd, SFX_patch_1..3.snd hold the sounds. Same index layout as DOOM Eternal's .snd (tools/doom_snd.py);
     a later patch overrides an earlier file. Each sound is a RIFF/WAVE file whose codec is Wwise Opus (0x3041).
  3. vgmstream-cli (ISC licence, downloaded by the setup) decodes them to 48 kHz stereo WAV, which is what
     doomslayer.dll plays.

    python tools/darkages_sounds.py
"""
import re
import statistics
import subprocess
import sys
import wave
import array
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import darkages_events  # noqa: E402
import doom_snd  # noqa: E402
import paths  # noqa: E402

# doom_audio event -> (Wwise event, most variants to keep)
EVENTS = {
    "ssg_fire": ("play_plr_wpn_ssg_fire", 16, 1.1),
    "ssg_reload": ("play_plr_wpn_ssg_reload", 3),
    "ssg_reload_click": ("play_plr_wpn_ssg_reload_click", 3),
    "ssg_intro": ("play_plr_wpn_ssg_intro", 1),
    "ssg_intro_grab": ("play_plr_wpn_ssg_intro_grab", 1),
    "ssg_twirl": ("play_plr_wpn_ssg_last_shot_twirl", 1),
    "ssg_modswap": ("play_plr_wpn_ssg_modswap", 1),
    # the Flail
    "flail_intro": ("play_plr_wpn_flail_intro", 1),
    "flail_swing": ("play_player_weapon_flail_swing_quick", 3),
    "flail_swing2": ("play_player_weapon_flail_swing_quick_2nd", 2),
    "flail_pullback_l": ("play_player_wpn_flail_pullback_left", 3),
    "flail_pullback_r": ("play_player_wpn_flail_pullback_right", 3),
    "flail_impact": ("play_player_weapon_flail_impact", 8, 0.9),
    "flail_prop_impact": ("play_player_weapon_flail_prop_impact", 3),
}


# Wwise sounds are mixed quiet and get their loudness from the game's mixer, so these play too softly as plain WAVs.
# Events listed here are made louder so their loudest peak reaches this level (1.0 = full scale), the same gain for
# every variant of the event (they keep their loudness relative to each other). Raise a number for louder,
# lower it for quieter; remove a line to leave the sound as decoded. Gain is capped at x16 (+24 dB).
LOUDNESS = {
    "ssg_fire": 0.95,
    "flail_impact": 0.95,
}
MAX_GAIN = 16.0


def make_louder(files, target):
    """Scale 16-bit WAVs by one common gain so the loudest sample hits `target` (no clipping). Returns the gain."""
    import array
    data = []
    for f in files:
        with wave.open(str(f), "rb") as w:
            if w.getsampwidth() != 2:
                return 1.0
            data.append((w.getparams(), array.array("h", w.readframes(w.getnframes()))))
    peak = max((max((abs(v) for v in a), default=0) for _, a in data), default=0)
    if peak == 0:
        return 1.0
    gain = min(target * 32767.0 / peak, MAX_GAIN)
    if gain <= 1.02:
        return 1.0
    for f, (params, a) in zip(files, data):
        out = array.array("h", (max(-32768, min(32767, int(v * gain))) for v in a))
        with wave.open(str(f), "wb") as w:
            w.setparams(params)
            w.writeframes(out.tobytes())
    return gain


def snd_files(sb):
    """SFX.snd then its patches in patch order (later ones win)."""
    def key(p):
        m = re.search(r"_patch_(\d+)", p.name)
        return int(m.group(1)) if m else 0
    return sorted((p for p in Path(sb).glob("SFX*.snd") if re.fullmatch(r"SFX(_patch_\d+)?\.snd", p.name)), key=key)


def index(sb):
    """{sound id: (snd file, (offset, size, format))}"""
    out = {}
    for f in snd_files(sb):
        for sid, rec in doom_snd.records(f).items():
            out[sid] = (f, rec)
    return out


def duration(wav_path):
    with wave.open(str(wav_path), "rb") as w:
        return w.getnframes() / w.getframerate()


def tail_ratio(wav_path, after=0.30):
    """Share of the sound's energy that comes after `after` seconds: a dry shot or hit is near 0, a version with
    the room's echo / reverb tail (Wwise plays those as separate layers) is high."""
    with wave.open(str(wav_path), "rb") as w:
        n, ch, sw, rate = w.getnframes(), w.getnchannels(), w.getsampwidth(), w.getframerate()
        raw = w.readframes(n)
    if sw != 2:
        return 0.0
    a = array.array("h")
    a.frombytes(raw)
    cut = int(after * rate) * ch
    tot = sum(x * x for x in a) or 1
    return sum(x * x for x in a[cut:]) / tot


# Echo control (edit and run the setup again): event -> (seconds the body lasts, dB the echo after it is turned down).
# -6 = still strong, -12 = gentle, -20 = barely there, 0 = untouched.
TAIL = {
    "flail_impact": (0.15, -14.0),
}


# A little added echo (the dry sound plus a few fading repeats): event -> dB of the first repeat. -10 = clear echo,
# -16 = little, -24 = a hint, 0 / missing = none.
ADD_ECHO = {
    "ssg_fire": -16.0,
}


def trim(wav_path, dest, max_len, fade=0.06, tail=None, echo_db=None):
    """Copy the sound cut to `max_len` seconds with a short fade out (no abrupt end, no long echo)."""
    with wave.open(str(wav_path), "rb") as w:
        params, rate, ch, sw = w.getparams(), w.getframerate(), w.getnchannels(), w.getsampwidth()
        raw = w.readframes(w.getnframes())
    if sw != 2 or max_len <= 0:
        Path(dest).write_bytes(Path(wav_path).read_bytes())
        return
    a = array.array("h")
    a.frombytes(raw)
    keep = min(len(a), int(max_len * rate) * ch)
    a = a[:keep]
    f = min(int(fade * rate), len(a) // ch)
    if tail:
        # keep the hit itself, bring everything after `body` seconds down to `db` over 80 ms
        body, db = tail
        lo, ramp = 10 ** (db / 20.0), int(0.08 * rate)
        start = int(body * rate)
        for i in range(len(a) // ch):
            k = min(max(i - start, 0), ramp) / max(ramp, 1)
            g = 1.0 - k * (1.0 - lo)
            if g != 1.0:
                for c in range(ch):
                    a[i * ch + c] = int(a[i * ch + c] * g)
    if echo_db is not None:
        # three fading repeats (110, 210, 340 ms), then 0.45 s of room for them to ring out
        n = len(a) // ch
        out = array.array("h", a) + array.array("h", [0] * (int(0.45 * rate) * ch))
        buf = [float(x) for x in out]
        for k, delay in enumerate((0.11, 0.21, 0.34)):
            gain = 10 ** (echo_db / 20.0) * (0.6 ** k)
            d = int(delay * rate)
            for i in range(n * ch):
                j = i + d * ch
                if j < len(buf):
                    buf[j] += a[i] * gain
        a = array.array("h", [max(-32768, min(32767, int(x))) for x in buf])
        f = min(int(0.2 * rate), len(a) // ch)
    for i in range(f):
        g = 1.0 - i / max(f, 1)
        for c in range(ch):
            j = (len(a) // ch - f + i) * ch + c
            a[j] = int(a[j] * g)
    with wave.open(str(dest), "wb") as o:
        o.setnchannels(ch)
        o.setsampwidth(sw)
        o.setframerate(rate)
        o.writeframes(a.tobytes())


VGMSTREAM_URL = "https://github.com/vgmstream/vgmstream-releases/releases/download/nightly/vgmstream-win64.zip"


def ensure_vgmstream():
    """Make sure vgmstream-cli can be run; when run by hand and it is nowhere to be found, download it (needs internet)."""
    import os
    import shutil
    import urllib.request
    import zipfile
    cur = Path(str(paths.VGMSTREAM))
    if cur.is_file() or shutil.which(str(paths.VGMSTREAM)):
        return
    base = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "DRSetup" / "vgmstream"
    exe = next(iter(base.rglob("vgmstream-cli.exe")), None) if base.exists() else None
    if exe is None:
        base.mkdir(parents=True, exist_ok=True)
        print("downloading vgmstream (audio decoder) ...")
        zp = base / "vgmstream-win64.zip"
        urllib.request.urlretrieve(VGMSTREAM_URL, zp)
        with zipfile.ZipFile(zp) as z:
            z.extractall(base)
        exe = next(iter(base.rglob("vgmstream-cli.exe")), None)
    if exe is None:
        raise SystemExit("vgmstream-cli.exe could not be found or downloaded")
    paths.VGMSTREAM = str(exe)
    print("vgmstream:", exe)


def decode(wem, wav):
    r = subprocess.run([str(paths.VGMSTREAM), "-o", str(wav), str(wem)], capture_output=True, text=True,
                       creationflags=paths.NO_WINDOW)
    if r.returncode != 0 or not Path(wav).exists():
        raise RuntimeError(f"vgmstream failed on {Path(wem).name}: {(r.stdout + r.stderr).strip()[-300:]}")


def pick(durs, keep, variants):
    """Variants of one event that sound alike: close to the median length (an event can also list long tails and
    distant versions). Single-sound events keep what they have."""
    if not variants or len(durs) <= 1:
        return list(durs)[:keep]
    med = statistics.median(durs.values())
    ok = [i for i, d in durs.items() if 0.5 * med <= d <= 1.6 * med]
    return sorted(ok, key=lambda i: abs(durs[i] - med))[:keep]


# Fixed sounds picked by ear (sound id), each its own event so the game plays them together.
FIXED = {
    "flail_glory1": 741400105,
    "flail_glory2": 407541944,
    "flail_glory3": 118443324,
}

PICKS = Path(__file__).resolve().parent / "data" / "sound_picks.json"


def load_picks():
    """tools/data/sound_picks.json: {"ssg_fire": [sound ids...]} chosen by ear with ssg_audition.py. An event listed
    there uses exactly those sounds (no automatic choice, nothing dropped)."""
    try:
        import json
        d = json.loads(PICKS.read_text())
        return {k: [int(i) for i in v] for k, v in d.items() if not k.startswith("_") and v}
    except (OSError, ValueError):
        return {}


def main():
    ensure_vgmstream()
    picks = load_picks()
    sb = doom_snd.soundbanks(paths.DOOM_BASE)
    events = darkages_events.read_events(sb / "soundmetadata.bin")
    idx = index(sb)
    work = paths.WORK / "ssg_sound"
    work.mkdir(parents=True, exist_ok=True)
    total = 0
    report = []
    for out_name, spec in EVENTS.items():
        wwise, keep = spec[0], spec[1]
        max_len = spec[2] if len(spec) > 2 else 0.0
        ev = events.get(wwise)
        if ev is None:
            print(f"!! event {wwise} not in soundmetadata.bin")
            continue
        if out_name in picks:
            want = list(dict.fromkeys(picks[out_name]))
            print(f"{out_name}: sound_picks.json lists {len(want)} ids: {want}")
            for i in want:
                if i not in idx:
                    print(f"  !! id {i} is not in the sound banks (typo?)")
                elif i not in ev["sound_ids"]:
                    print(f"  (id {i} is not one of {wwise}'s own sounds, using it anyway)")
        found = [i for i in dict.fromkeys(picks.get(out_name) or ev["sound_ids"]) if i in idx]
        if not found:
            print(f"!! {wwise}: none of its {len(ev['sound_ids'])} sounds are in the banks")
            continue
        wavs, durs = {}, {}
        for sid in found:
            f, rec = idx[sid]
            wem = work / f"{sid}.wem"
            wem.write_bytes(doom_snd.read(f, rec))
            wav = work / f"{sid}.wav"
            decode(wem, wav)
            wavs[sid], durs[sid] = wav, duration(wav)
        tails = {sid: tail_ratio(wavs[sid]) for sid in wavs}
        for sid in wavs:
            report.append(f"{out_name} {sid} {durs[sid]:.2f}s tail {tails[sid]:.2f}")
        if max_len and len(found) > 3:
            # layered events (shot + room echo versions): keep the DRY ones - least energy late in the sound
            best = min(tails.values())
            dry = {i: d for i, d in durs.items() if tails[i] <= best + 0.08 and d <= max_len * 1.6}
            chosen = pick(dry or durs, keep, True)
        else:
            chosen = list(found) if out_name in picks else pick(durs, keep, len(found) > 3)
        dest = paths.NATIVES / "doom_audio" / out_name
        dest.mkdir(parents=True, exist_ok=True)
        for old in dest.glob("*.wav"):
            old.unlink()
        for n, sid in enumerate(chosen, 1):
            trim(wavs[sid], dest / f"{n}.wav", max_len, tail=TAIL.get(out_name), echo_db=ADD_ECHO.get(out_name))
        total += len(chosen)
        note = ""
        if out_name in LOUDNESS:
            g = make_louder(sorted(dest.glob("*.wav")), LOUDNESS[out_name])
            if g != 1.0:
                note = f", louder x{g:.1f}"
        print(f"{out_name}: {len(chosen)} of {len(found)} sounds ({wwise}){note}")
    (work / "sounds_report.txt").write_text("\n".join(report))
    for out_name, sid in FIXED.items():
        if sid not in idx:
            print(f"!! {out_name}: sound id {sid} is not in the sound banks")
            continue
        f, rec = idx[sid]
        wem, wav = work / f"{sid}.wem", work / f"{sid}.wav"
        wem.write_bytes(doom_snd.read(f, rec))
        decode(wem, wav)
        dest = paths.NATIVES / "doom_audio" / out_name
        dest.mkdir(parents=True, exist_ok=True)
        for old in dest.glob("*.wav"):
            old.unlink()
        (dest / "1.wav").write_bytes(wav.read_bytes())
        g = make_louder([dest / "1.wav"], 0.95)
        print(f"{out_name}: id {sid}" + (f", louder x{g:.1f}" if g != 1.0 else ""))
        total += 1
    if total == 0:
        raise SystemExit("no Super Shotgun sounds could be extracted")
    print(f"{total} sound files -> {paths.NATIVES / 'doom_audio'}")


if __name__ == "__main__":
    main()
