"""Super Shotgun sounds from the player's own DOOM The Dark Ages install -> doom_audio/<event>/<n>.wav

How (all checked on a real install):
  1. base/sound/soundbanks/pc/soundmetadata.bin says which sound ids each Wwise event plays
     (tools/darkages_events.py).
  2. SFX.snd, SFX_patch_1..3.snd hold the sounds. Same index layout as DOOM Eternal's .snd (tools/doom_snd.py);
     a later patch overrides an earlier file. Each sound is a RIFF/WAVE file whose codec is Wwise Opus (0x3041).
  3. vgmstream-cli (ISC licence, downloaded by the setup) decodes them to 48 kHz stereo WAV, which is what
     doomslayer.dll plays.

    python tools/darkages_sounds.py
"""
import re
import statistics
import subprocess
import sys
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import darkages_events  # noqa: E402
import doom_snd  # noqa: E402
import paths  # noqa: E402

# doom_audio event -> (Wwise event, most variants to keep)
EVENTS = {
    "ssg_fire": ("play_plr_wpn_ssg_fire", 16),
    "ssg_reload": ("play_plr_wpn_ssg_reload", 3),
    "ssg_reload_click": ("play_plr_wpn_ssg_reload_click", 3),
    "ssg_intro": ("play_plr_wpn_ssg_intro", 1),
    "ssg_intro_grab": ("play_plr_wpn_ssg_intro_grab", 1),
    "ssg_twirl": ("play_plr_wpn_ssg_last_shot_twirl", 1),
    "ssg_modswap": ("play_plr_wpn_ssg_modswap", 1),
    # the Flail
    "flail_intro": ("play_plr_wpn_flail_intro", 1),
    "flail_swing": ("play_player_weapon_flail_swing_quick", 3),
    "flail_swing2": ("play_player_weapon_flail_swing_quick_2nd", 2),
    "flail_pullback_l": ("play_player_wpn_flail_pullback_left", 3),
    "flail_pullback_r": ("play_player_wpn_flail_pullback_right", 3),
    "flail_impact": ("play_player_weapon_flail_impact", 8),
    "flail_prop_impact": ("play_player_weapon_flail_prop_impact", 3),
}


def snd_files(sb):
    """SFX.snd then its patches in patch order (later ones win)."""
    def key(p):
        m = re.search(r"_patch_(\d+)", p.name)
        return int(m.group(1)) if m else 0
    return sorted((p for p in Path(sb).glob("SFX*.snd") if re.fullmatch(r"SFX(_patch_\d+)?\.snd", p.name)), key=key)


def index(sb):
    """{sound id: (snd file, (offset, size, format))}"""
    out = {}
    for f in snd_files(sb):
        for sid, rec in doom_snd.records(f).items():
            out[sid] = (f, rec)
    return out


def duration(wav_path):
    with wave.open(str(wav_path), "rb") as w:
        return w.getnframes() / w.getframerate()


def decode(wem, wav):
    r = subprocess.run([str(paths.VGMSTREAM), "-o", str(wav), str(wem)], capture_output=True, text=True,
                       creationflags=paths.NO_WINDOW)
    if r.returncode != 0 or not Path(wav).exists():
        raise RuntimeError(f"vgmstream failed on {Path(wem).name}: {(r.stdout + r.stderr).strip()[-300:]}")


def pick(durs, keep, variants):
    """Variants of one event that sound alike: close to the median length (an event can also list long tails and
    distant versions). Single-sound events keep what they have."""
    if not variants or len(durs) <= 1:
        return list(durs)[:keep]
    med = statistics.median(durs.values())
    ok = [i for i, d in durs.items() if 0.5 * med <= d <= 1.6 * med]
    return sorted(ok, key=lambda i: abs(durs[i] - med))[:keep]


def main():
    sb = doom_snd.soundbanks(paths.DOOM_BASE)
    events = darkages_events.read_events(sb / "soundmetadata.bin")
    idx = index(sb)
    work = paths.WORK / "ssg_sound"
    work.mkdir(parents=True, exist_ok=True)
    total = 0
    for out_name, (wwise, keep) in EVENTS.items():
        ev = events.get(wwise)
        if ev is None:
            print(f"!! event {wwise} not in soundmetadata.bin")
            continue
        found = [i for i in dict.fromkeys(ev["sound_ids"]) if i in idx]
        if not found:
            print(f"!! {wwise}: none of its {len(ev['sound_ids'])} sounds are in the banks")
            continue
        wavs, durs = {}, {}
        for sid in found:
            f, rec = idx[sid]
            wem = work / f"{sid}.wem"
            wem.write_bytes(doom_snd.read(f, rec))
            wav = work / f"{sid}.wav"
            decode(wem, wav)
            wavs[sid], durs[sid] = wav, duration(wav)
        chosen = pick(durs, keep, len(found) > 3)
        dest = paths.NATIVES / "doom_audio" / out_name
        dest.mkdir(parents=True, exist_ok=True)
        for old in dest.glob("*.wav"):
            old.unlink()
        for n, sid in enumerate(chosen, 1):
            (dest / f"{n}.wav").write_bytes(wavs[sid].read_bytes())
        total += len(chosen)
        print(f"{out_name}: {len(chosen)} of {len(found)} sounds ({wwise})")
    if total == 0:
        raise SystemExit("no Super Shotgun sounds could be extracted")
    print(f"{total} sound files -> {paths.NATIVES / 'doom_audio'}")


if __name__ == "__main__":
    main()
