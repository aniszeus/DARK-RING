"""Listen to EVERY sound a DOOM The Dark Ages event plays, to choose the right ones by ear.  In IDLE: open, press F5.

It decodes all the sounds of the events listed in EVENTS below into  audition/<event>/  (the folder is printed at the
end), named  <number>_id<sound id>_<seconds>s.wav , shortest first, each made loud enough to hear. Listen
(Audacity / any player), note the ids of the ones you want, then write them in
    tools/data/sound_picks.json     like   {"ssg_fire": [123456, 234567]}
and run the setup again: an event listed there uses exactly those sounds.
"""
import array
import sys
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import darkages_events  # noqa: E402
import darkages_sounds as ds  # noqa: E402
import doom_snd  # noqa: E402
import paths  # noqa: E402

EVENTS = ["ssg_fire", "flail_impact"]   # names from darkages_sounds.EVENTS


def main():
    ds.ensure_vgmstream()
    sb = doom_snd.soundbanks(paths.DOOM_BASE)
    events = darkages_events.read_events(sb / "soundmetadata.bin")
    idx = ds.index(sb)
    root = paths.WORK / "audition"
    for name in EVENTS:
        wwise = ds.EVENTS[name][0]
        ev = events.get(wwise)
        if ev is None:
            print("event not found:", wwise)
            continue
        ids = [i for i in dict.fromkeys(ev["sound_ids"]) if i in idx]
        tmp = root / "_tmp"
        tmp.mkdir(parents=True, exist_ok=True)
        rows = []
        for sid in ids:
            f, rec = idx[sid]
            wem, wav = tmp / f"{sid}.wem", tmp / f"{sid}.wav"
            wem.write_bytes(doom_snd.read(f, rec))
            try:
                ds.decode(wem, wav)
            except RuntimeError as e:
                print("skip", sid, e)
                continue
            rows.append((ds.duration(wav), sid, wav))
        rows.sort()
        out = root / name
        out.mkdir(parents=True, exist_ok=True)
        for old in out.glob("*.wav"):
            old.unlink()
        for n, (dur, sid, wav) in enumerate(rows, 1):
            with wave.open(str(wav), "rb") as w:
                params, a = w.getparams(), array.array("h", w.readframes(w.getnframes()))
            pk = max((abs(v) for v in a), default=0)
            if pk:
                g = min(0.9 * 32767 / pk, 40.0)
                a = array.array("h", (max(-32768, min(32767, int(v * g))) for v in a))
            with wave.open(str(out / f"{n:03d}_id{sid}_{dur:.2f}s.wav"), "wb") as w:
                w.setparams(params)
                w.writeframes(a.tobytes())
        print(f"{name}: {len(rows)} sounds -> {out}")
    print("Done. Listen, then put the ids you want in tools/data/sound_picks.json and run the setup again.")


main()
