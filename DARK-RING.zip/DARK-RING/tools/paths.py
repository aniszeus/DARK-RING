"""Where the converters read and write. Defaults = the development PC; the installer sets the
DOOMRING_* environment variables (the player's DOOM The Dark Ages install, a work folder, the output).
"""
import os
import shutil
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]


def _find_game():
    """The DOOM The Dark Ages folder when a tool is run by hand (the setup passes DOOMRING_DOOM): next to / above
    these scripts, then Steam libraries on every drive."""
    if os.environ.get("DOOMRING_DOOM"):
        return Path(os.environ["DOOMRING_DOOM"])
    exe = "DOOMTheDarkAges.exe"
    cands = [REPO, REPO.parent]
    tails = ["SteamLibrary/steamapps/common/DOOMTheDarkAges", "Steam/steamapps/common/DOOMTheDarkAges",
             "Program Files (x86)/Steam/steamapps/common/DOOMTheDarkAges", "Program Files/Steam/steamapps/common/DOOMTheDarkAges",
             "Games/SteamLibrary/steamapps/common/DOOMTheDarkAges"]
    if os.name == "nt":
        for d in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            cands += [Path(f"{d}:/") / t for t in tails]
    for c in cands:
        try:
            if (c / exe).exists():
                return c
        except OSError:
            pass
    return Path("C:/Program Files (x86)/Steam/steamapps/common/DOOMTheDarkAges")


DOOM = _find_game()
DOOM_BASE = DOOM / "base"
# work files (extracted sounds / music, SAMUEL exports); never shipped
WORK = Path(os.environ.get("DOOMRING_WORK", Path.home() / "doom-extract"))
# the mod's natives folder (doom_audio, doom_music, doom_ui, doom_fx, doom_vm)
NATIVES = Path(os.environ.get("DOOMRING_OUT", REPO / "dist" / "natives"))
SAMUEL = Path(os.environ.get("DOOMRING_SAMUEL", Path.home() / "modtools/samuel-src/build/samuel-cli.exe"))
EAE = Path(os.environ.get("DOOMRING_EAE", Path.home() / "modtools/eae/EternalAudioExtractor.exe"))
# vgmstream-cli decodes DOOM The Dark Ages' Wwise Opus sounds (DARK RING)
def _find_vgmstream():
    """The env var from the setup, PATH, or the copy the setup downloaded (%LOCALAPPDATA%/DRSetup/vgmstream)."""
    if os.environ.get("DOOMRING_VGMSTREAM"):
        return os.environ["DOOMRING_VGMSTREAM"]
    found = shutil.which("vgmstream-cli")
    if found:
        return found
    base = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "DRSetup" / "vgmstream"
    try:
        for f in base.rglob("vgmstream-cli*"):
            if f.is_file() and f.suffix.lower() in ("", ".exe"):
                return str(f)
    except OSError:
        pass
    return "vgmstream-cli"


VGMSTREAM = _find_vgmstream()
FFMPEG = os.environ.get("DOOMRING_FFMPEG") or shutil.which("ffmpeg") or "ffmpeg"
FFPROBE = os.environ.get("DOOMRING_FFPROBE") or shutil.which("ffprobe") or "ffprobe"
# no console window per tool run (Windows)
NO_WINDOW = 0x08000000 if os.name == "nt" else 0

if os.name == "nt":
    # Every helper (samuel-cli, ffmpeg, ww2ogg) runs without a console window: started from the
    # windowless setup, a console tool would otherwise open its own window each time.
    import subprocess as _sp

    _popen_init = _sp.Popen.__init__

    def _no_window_init(self, *args, **kwargs):
        if not kwargs.get("creationflags"):
            kwargs["creationflags"] = NO_WINDOW
        _popen_init(self, *args, **kwargs)

    if getattr(_sp.Popen.__init__, "__name__", "") != "_no_window_init":
        _sp.Popen.__init__ = _no_window_init
