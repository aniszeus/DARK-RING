"""Read DOOM The Dark Ages' sound event table: which Wwise event plays which sound ids.

File: base/sound/soundbanks/pc/soundmetadata.bin (little endian). Worked out from a real install:

  table 1 (names):   u32 count, then per event  u32 len, name, u32 event id, u8 0 (1 = voice bank), u32 len, bank
  ... other tables (ducking, states, switches, languages) ...
  table 2 (events):  per event  u32 len, name, u32 event id, 11 bytes (flags / a float),
                     u32 reference count, then per reference  u32 sound id, u32 len, bank name ("SFX")

The event id is Wwise's FNV-1 32-bit hash of the lower-case name (true for all 4768 names checked), which
is how table 2 is found without knowing its offset: a run of records whose hash matches their name.

    python tools/darkages_events.py <soundmetadata.bin> <event name regex>
"""
import json
import re
import struct
import sys
from pathlib import Path

GAP = 11


def fnv1(name):
    h = 2166136261
    for c in name.lower().encode():
        h = (h * 16777619) & 0xFFFFFFFF
        h ^= c
    return h


def _event(b, p):
    """(name, id, [(sound id, bank)], next offset) or None when no valid record starts at p."""
    if p + 8 > len(b):
        return None
    n = struct.unpack_from("<I", b, p)[0]
    if not 3 <= n < 200:
        return None
    raw = b[p + 4:p + 4 + n]
    if not all(32 <= c < 127 for c in raw):
        return None
    name = raw.decode()
    eid = struct.unpack_from("<I", b, p + 4 + n)[0]
    if fnv1(name) != eid:
        return None
    q = p + 4 + n + 4 + GAP
    if q + 4 > len(b):
        return None
    cnt = struct.unpack_from("<I", b, q)[0]
    if cnt > 5000:
        return None
    q += 4
    refs = []
    for _ in range(cnt):
        if q + 8 > len(b):
            return None
        rid, bl = struct.unpack_from("<II", b, q)
        if bl > 20:
            return None
        refs.append((rid, b[q + 8:q + 8 + bl].decode("latin1")))
        q += 8 + bl
    return name, eid, refs, q


def read_events(path, start_after=0):
    """{event name: {"id": event id, "sound_ids": [...]}} for the whole event table."""
    b = Path(path).read_bytes()
    # table 1 ends where its `count` records end; table 2 is the first valid chain after it
    count = struct.unpack_from("<I", b, 0)[0]
    pos = 4
    for _ in range(count):
        n = struct.unpack_from("<I", b, pos)[0]
        bl = struct.unpack_from("<I", b, pos + 9 + n)[0]
        pos += 13 + n + bl
    first = None
    for p in range(max(pos, start_after), len(b) - 12):
        if _event(b, p):
            first = p
            break
    if first is None:
        raise ValueError("no event table found: the soundmetadata.bin layout changed")
    out, p = {}, first
    while True:
        r = _event(b, p)
        if not r:
            break
        out[r[0]] = {"id": r[1], "sound_ids": [x[0] for x in r[2]]}
        p = r[3]
    return out


if __name__ == "__main__":
    ev = read_events(sys.argv[1])
    pat = re.compile(sys.argv[2], re.I) if len(sys.argv) > 2 else None
    print(f"{len(ev)} events")
    for n, e in sorted(ev.items()):
        if pat is None or pat.search(n):
            print(f"  {n:50s} 0x{e['id']:08x}  {len(e['sound_ids'])} sound ids")
    if pat:
        out = Path(__file__).resolve().parent / "data" / "darkages_ssg_events.json"
        out.write_text(json.dumps({"_note": "event names, event ids and sound ids only (no audio)",
                                   "events": {n: e for n, e in sorted(ev.items()) if pat.search(n)}}, indent=1))
        print("wrote", out)
