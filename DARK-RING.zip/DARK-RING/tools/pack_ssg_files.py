"""Zip the Super Shotgun files from your DOOM The Dark Ages folder, for DARK RING. In IDLE: open, press F5.

It copies (never changes) these into  ssg_files.zip  next to this script:
  - the arms and gun models   (arms.cast, doomslayer_1p_praetor.cast, shotgun.cast)
  - every .cast animation anywhere in the game folder whose path has "double_barrel" or "shotgun"
  - every .cast MODEL whose path has "double_barrel", "shotgun" or "ssg" (the Super Shotgun has its own model)
  - sound metadata names      (soundmetadata.bin, ~1 MB)
No textures this time. Send ssg_files.zip back.
"""
import os
import sys
import zipfile

CANDIDATES = [r"H:\SteamLibrary\steamapps\common\DOOMTheDarkAges",
              r"C:\Program Files (x86)\Steam\steamapps\common\DOOMTheDarkAges"]
MODELS = ["exported_files/models/md6/player/doomslayer_1p/base/assets/mesh/arms.cast",
          "exported_files/models/md6/player/doomslayer_1p/base/assets/mesh/doomslayer_1p_praetor.cast",
          "exported_files/models/md6/weapons/shotgun/base/assets/mesh/shotgun.cast",
          "base/sound/soundbanks/pc/soundmetadata.bin"]


def find_game():
    here = os.path.dirname(os.path.abspath(__file__))
    for c in [os.path.dirname(here), *CANDIDATES]:
        if os.path.exists(os.path.join(c, "DOOMTheDarkAges.exe")):
            return c
    p = input("Path to your DOOMTheDarkAges folder: ").strip().strip('"')
    if not os.path.exists(os.path.join(p, "DOOMTheDarkAges.exe")):
        sys.exit("DOOMTheDarkAges.exe not found in that folder.")
    return p


def main():
    game = find_game()
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ssg_files.zip")
    files = [os.path.join(game, *m.split("/")) for m in MODELS]
    anims = []
    for dirpath, _dirs, names in os.walk(game):
        low = dirpath.replace("\\", "/").lower()
        if "animations" not in low or not ("double_barrel" in low or "shotgun" in low or any("double_barrel" in x.lower() for x in names)):
            continue
        anims += [os.path.join(dirpath, x) for x in names if x.lower().endswith(".cast")]
    print(f"Found {len(anims)} shotgun animation files:")
    folders = {}
    for f in anims:
        folders[os.path.dirname(f)] = folders.get(os.path.dirname(f), 0) + 1
    for d, c in sorted(folders.items()):
        print(f"  {c:3d}  {os.path.relpath(d, game)}")
    if not anims:
        print("  NONE. Export the Super Shotgun animations with Serrat into this game folder, then run this again.")
    files += anims
    models = []
    for dirpath, _dirs, names in os.walk(game):
        low = dirpath.replace("\\", "/").lower()
        if "/models" not in low and "models/" not in low:
            continue
        for x in names:
            full = os.path.join(dirpath, x)
            lowp = (low + "/" + x).lower()
            if x.lower().endswith(".cast") and any(k in lowp for k in ("double_barrel", "shotgun", "ssg")) and full not in files:
                models.append(full)
    print(f"Found {len(models)} more shotgun model files:")
    for f in models:
        print(f"  {os.path.relpath(f, game)}  ({os.path.getsize(f) / 1e6:.1f} MB)")
    if not any("double_barrel" in m.lower() for m in models):
        print("  No model with 'double_barrel' in its path. In Serrat, open Models, search for  double_barrel  and export it"
              " (Cast format), then run this again.")
    files += models
    n = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            if os.path.exists(f):
                z.write(f, os.path.relpath(f, game).replace("\\", "/"))
                n += 1
            else:
                print("missing:", f)
    print(f"Packed {n} files into {out} ({os.path.getsize(out) / 1e6:.1f} MB).")
    print("Send that zip.")


main()
