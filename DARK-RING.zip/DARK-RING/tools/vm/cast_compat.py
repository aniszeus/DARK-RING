"""The small part of the official `cast` Python module that convert_weapon.py uses, on top of cast_read.

convert_weapon.py was written against dtzxporter's `cast` module (Vega's exports). Serrat writes the
same Cast format, so with this shim the "vega" source mode can read Serrat's DOOM The Dark Ages exports:

    import cast_compat as cast
    c = cast.Cast.load("shotgun.cast")
    for root in c.Roots():
        for model in root.ChildrenOfType(cast.Model): ...

Only what the converter calls is here (skeleton, meshes, materials, animation curves).
"""
import numpy as np

import cast_read


class _Wrap:
    def __init__(self, node, parent=None):
        self.node = node
        self.parent = parent

    def Name(self):
        return self.node.name


class Bone(_Wrap):
    def ParentIndex(self):
        p = self.node.get("p")
        if p is None or int(p[0]) == 0xFFFFFFFF:
            return -1
        return int(p[0])

    def LocalPosition(self):
        v = self.node.get("lp")
        return tuple(v[0]) if v is not None else (0.0, 0.0, 0.0)

    def LocalRotation(self):
        v = self.node.get("lr")
        return tuple(v[0]) if v is not None else (0.0, 0.0, 0.0, 1.0)


class Skeleton(_Wrap):
    def Bones(self):
        return [Bone(c, self) for c in self.node.children if c.kind == "bone"]


class Material(_Wrap):
    pass


class Mesh(_Wrap):
    def Material(self):
        h = self.node.get("m")
        if h is None or self.parent is None:
            return None
        return self.parent._materials.get(int(h[0]))

    def VertexPositionBuffer(self):
        return self.node.get("vp").ravel()

    def VertexNormalBuffer(self):
        v = self.node.get("vn")
        return v.ravel() if v is not None else np.tile(np.array([0, 0, 1], np.float32), len(self.node.get("vp")))

    def VertexUVLayerBuffer(self, layer):
        v = self.node.get(f"u{layer}")
        return v.ravel() if v is not None else np.zeros(len(self.node.get("vp")) * 2, np.float32)

    def MaximumWeightInfluence(self):
        mi = self.node.get("mi")
        return int(mi[0]) if mi is not None and self.node.get("wb") is not None else 0

    def VertexWeightBoneBuffer(self):
        return self.node.get("wb")

    def VertexWeightValueBuffer(self):
        return self.node.get("wv")

    def FaceBuffer(self):
        return self.node.get("f")


class Model(_Wrap):
    def __init__(self, node, parent=None):
        super().__init__(node, parent)
        self._materials = {m.hash: Material(m, self) for m in node.children if m.kind == "matl"}

    def Skeleton(self):
        s = [c for c in self.node.children if c.kind == "skel"]
        return Skeleton(s[0], self) if s else None

    def Meshes(self):
        return [Mesh(c, self) for c in self.node.children if c.kind == "mesh"]


class Curve(_Wrap):
    def NodeName(self):
        return self.node.get("nn")

    def KeyPropertyName(self):
        return self.node.get("kp")

    def KeyFrameBuffer(self):
        return self.node.get("kb")

    def KeyValueBuffer(self):
        return np.asarray(self.node.get("kv")).ravel()

    def Mode(self):
        return self.node.get("m")


class Animation(_Wrap):
    def Framerate(self):
        fr = self.node.get("fr")
        return float(fr[0]) if fr is not None else 0.0

    def Curves(self):
        return [Curve(c, self) for c in self.node.children if c.kind == "curv"]


_CLASSES = {"modl": Model, "anim": Animation}


class Root(_Wrap):
    def ChildrenOfType(self, cls):
        return [cls(c, self) for c in self.node.children if _CLASSES.get(c.kind) is cls]


class Cast:
    def __init__(self, roots):
        self._roots = roots

    @classmethod
    def load(cls, path):
        return cls([Root(r) for r in cast_read.load(path)])

    def Roots(self):
        return self._roots
