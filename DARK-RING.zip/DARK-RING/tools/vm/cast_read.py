"""Minimal reader for Cast files (https://github.com/dtzxporter/cast), as Serrat writes them.

Layout (little endian, tightly packed):
  header   u32 'cast', u32 version, u32 root count, u32 flags
  node     u32 id, u32 size (this header + properties + all children), u64 hash, u32 property count, u32 child count
  property u16 type, u16 name length, u32 array length, name bytes, then the values
  types    b u8, h u16, i u32, l u64, f f32, d f64, s utf-8 NUL-terminated, v2 / v3 / v4 float vectors

    from cast_read import load
    roots = load("idle.cast")
    for bone in roots[0].find("skel")[0].children: print(bone.name, bone.get("p"))
"""
import struct
from pathlib import Path

import numpy as np

NODE_IDS = {0x746F6F72: "root", 0x6C646F6D: "modl", 0x6873656D: "mesh", 0x6C656B73: "skel", 0x656E6F62: "bone",
            0x6D696E61: "anim", 0x76727563: "curv", 0x6C74616D: "matl", 0x656C6966: "file", 0x726C6F63: "colr",
            0x74736E69: "inst", 0x6174656D: "meta", 0x72696168: "hair", 0x68736C62: "blnd", 0x64686B69: "ikhd",
            0x74736E63: "cnst", 0x564F4D43: "cmov", 0x6669746E: "ntrk"}
# property type -> (numpy dtype, components per element)
PROP_TYPES = {0x62: (np.uint8, 1), 0x68: (np.uint16, 1), 0x69: (np.uint32, 1), 0x6C: (np.uint64, 1),
              0x66: (np.float32, 1), 0x64: (np.float64, 1),
              0x7632: (np.float32, 2), 0x7633: (np.float32, 3), 0x7634: (np.float32, 4)}
STRING = 0x73


class CastError(ValueError):
    pass


class Node:
    def __init__(self, kind, hash_, props, children):
        self.kind = kind          # "mesh", "bone", "anim", ... or the raw id for unknown nodes
        self.hash = hash_
        self.props = props        # name -> value (str, or numpy array shaped (n,) / (n, k))
        self.children = children

    def get(self, name, default=None):
        return self.props.get(name, default)

    @property
    def name(self):
        return self.props.get("n", "")

    def find(self, kind):
        """Direct children of one kind."""
        return [c for c in self.children if c.kind == kind]

    def walk(self):
        yield self
        for c in self.children:
            yield from c.walk()

    def __repr__(self):
        return f"<{self.kind} {self.name!r} props={sorted(self.props)} children={len(self.children)}>"


def _read_property(buf, pos):
    ptype, name_len, count = struct.unpack_from("<HHI", buf, pos)
    pos += 8
    name = bytes(buf[pos:pos + name_len]).decode("utf-8", "replace")
    pos += name_len
    if ptype == STRING:
        end = buf.index(b"\x00", pos)
        return name, bytes(buf[pos:end]).decode("utf-8", "replace"), end + 1
    if ptype not in PROP_TYPES:
        raise CastError(f"unknown property type 0x{ptype:x} ({name})")
    dtype, comps = PROP_TYPES[ptype]
    n = count * comps
    size = n * np.dtype(dtype).itemsize
    arr = np.frombuffer(buf, dtype=dtype, count=n, offset=pos).copy()
    if comps > 1:
        arr = arr.reshape(count, comps)
    elif count == 1:
        arr = arr  # (1,) array; use .item() / [0] for a scalar
    return name, arr, pos + size


def _read_node(buf, pos):
    ident, size, hash_, nprops, nchildren = struct.unpack_from("<IIQII", buf, pos)
    start = pos + 24
    end = pos + size          # NodeSize counts the 24-byte node header too (checked on Serrat's files)
    p = start
    props = {}
    for _ in range(nprops):
        name, value, p = _read_property(buf, p)
        props[name] = value
    children = []
    for _ in range(nchildren):
        child, p = _read_node(buf, p)
        children.append(child)
    return Node(NODE_IDS.get(ident, ident), hash_, props, children), end


def parse(data):
    buf = bytes(data)
    if len(buf) < 16 or buf[:4] != b"cast":
        raise CastError("not a Cast file")
    _version, nroots, _flags = struct.unpack_from("<III", buf, 4)
    pos = 16
    roots = []
    for _ in range(nroots):
        node, pos = _read_node(buf, pos)
        roots.append(node)
    return roots


def load(path):
    return parse(Path(path).read_bytes())


def summary(roots):
    """A short text outline of the file (what the probe shows): node kinds, names, counts."""
    lines = []
    for r in roots:
        for n in r.walk():
            if n.kind in ("skel", "root", "modl", "anim"):
                lines.append(f"{n.kind} {n.name!r} children={len(n.children)} fr={n.get('fr')}")
            elif n.kind == "mesh":
                vp = n.get("vp")
                lines.append(f"  mesh {n.name!r} verts={0 if vp is None else len(vp)} "
                             f"faces={0 if n.get('f') is None else len(n.get('f')) // 3}")
            elif n.kind == "curv":
                kb = n.get("kb")
                lines.append(f"  curve {n.get('nn')} {n.get('kp')} keys={0 if kb is None else len(kb)} mode={n.get('m')}")
    return lines


# ----------------------------------------------------------------------------- test support
def _prop(ptype, name, value):
    nb = name.encode()
    if ptype == STRING:
        body = value.encode() + b"\x00"
        return struct.pack("<HHI", STRING, len(nb), 1) + nb + body
    dtype, comps = PROP_TYPES[ptype]
    arr = np.asarray(value, dtype=dtype)
    count = len(arr) if comps == 1 else arr.shape[0]
    return struct.pack("<HHI", ptype, len(nb), count) + nb + arr.tobytes()


def _node(ident, props, children=(), hash_=0):
    body = b"".join(props) + b"".join(children)
    return struct.pack("<IIQII", ident, 24 + len(body), hash_, len(props), len(children)) + body


def build_test_file():
    """A tiny Cast file written straight from the spec: 2 bones, 1 triangle mesh, 1 curve."""
    bones = [_node(0x656E6F62, [_prop(STRING, "n", "root"), _prop(0x69, "p", [0xFFFFFFFF]),
                                _prop(0x7634, "lr", [[0, 0, 0, 1]]), _prop(0x7633, "lp", [[0, 0, 0]])]),
             _node(0x656E6F62, [_prop(STRING, "n", "hand"), _prop(0x69, "p", [0]),
                                _prop(0x7634, "lr", [[0, 0, 0, 1]]), _prop(0x7633, "lp", [[0, 1, 0]])])]
    skel = _node(0x6C656B73, [], bones)
    mesh = _node(0x6873656D, [_prop(STRING, "n", "tri"), _prop(0x7633, "vp", [[0, 0, 0], [1, 0, 0], [0, 1, 0]]),
                              _prop(0x7633, "vn", [[0, 0, 1]] * 3), _prop(0x68, "f", [0, 1, 2]),
                              _prop(0x7632, "u0", [[0, 0], [1, 0], [0, 1]])])
    model = _node(0x6C646F6D, [], [skel, mesh])
    curve = _node(0x76727563, [_prop(STRING, "nn", "hand"), _prop(STRING, "kp", "tx"), _prop(0x68, "kb", [0, 5]),
                               _prop(0x66, "kv", [0.0, 2.5]), _prop(STRING, "m", "absolute")])
    anim = _node(0x6D696E61, [_prop(0x66, "fr", [30.0])], [curve])
    root = _node(0x746F6F72, [], [model, anim])
    return struct.pack("<4sIII", b"cast", 1, 1, 0) + root


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        print("\n".join(summary(load(sys.argv[1]))))
    else:
        roots = parse(build_test_file())
        print("\n".join(summary(roots)))
