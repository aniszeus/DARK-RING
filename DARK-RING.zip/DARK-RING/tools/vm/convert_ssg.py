"""Bake DOOM The Dark Ages' Super Shotgun (Praetor arms + gun + animations) into the model.bin that
doomslayer.dll draws (same DVM1 format as convert_weapon.py makes for DOOM Eternal).

Input: Cast exports of the player's own install (Serrat). Folders searched (DOOMRING_DA_EXPORT, several
separated by ';' or ':'; default: the Dark Ages folder next to this repo's tools or its parent):
    exported_files/models/md6/player/doomslayer_1p/base/assets/mesh/doomslayer_1p_praetor.cast
    exported_files/models/md6/weapons/shotgun/base/assets/mesh/shotgun.cast        (Combat Shotgun + SSG parts)
    exported_files/animations/md6/player/doomslayer_1p/base/motion/core/...        (arms + gun clips)
Output: <DOOMRING_VM_OUT or dist/natives/doom_vm>/super_shotgun/  model.bin, info.json, textures (png)

What differs from Eternal (all found on a real install, see DARK_RING_STATUS.md):
  * the gun is attached to the arms' `weapon_part01_rt` bone (Eternal: `righthandattach`);
  * the gun's own clips (`*__shotgun_double_barrel`) only move its parts; the arms of a shotgun are animated by
    the generic `core/shotgun/*__doomslayer_1p` clips (the double barrel's own arms clips are empty);
  * mesh names are empty: arms = meshes weighted to arm bones (left/right by bone suffix), the Super Shotgun =
    materials `supershotgun/ssg_*` (the Combat Shotgun's `combatshotgun*` and `upgrades/` parts are dropped).

    python tools/vm/convert_ssg.py [--preview out.png]
"""
import json
import os
import shutil
import struct
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import cast_compat as cast  # noqa: E402

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
OUT_ROOT = Path(os.environ.get("DOOMRING_VM_OUT", REPO / "dist" / "natives" / "doom_vm"))
NAME = "super_shotgun"

ARMS_MODEL = "models/md6/player/doomslayer_1p/base/assets/mesh/doomslayer_1p_praetor.cast"
GUN_MODEL = "models/md6/weapons/shotgun/base/assets/mesh/shotgun.cast"
CORE = "animations/md6/player/doomslayer_1p/base/motion/core"
ATTACH_BONE = "weapon_part01_rt"
CAMERA_BONE = "camera"

# clip -> (arms clip under core/, gun clip under core/shotguns/double_barrel/, options)
#   frames "max": run as long as the longer of the two (the shorter one holds its last pose)
ARMS = "shotgun/{}__doomslayer_1p"
GUN = "shotguns/double_barrel/{}__shotgun_double_barrel"
CLIPS = {
    "idle": (ARMS.format("idle"), GUN.format("idle_pose"), {}),
    "bringup": (ARMS.format("bringup"), GUN.format("idle_pose"), {}),
    "bringdown": (ARMS.format("bringdown"), GUN.format("idle_pose"), {}),
    "dryfire": (ARMS.format("dryfire"), GUN.format("dryfire"), {"frames": "max"}),
    "fire": (ARMS.format("shoot_classic_delay"), GUN.format("shoot_reload"), {"frames": "max"}),
    "fire_single": (ARMS.format("shoot_classic"), GUN.format("shootsingle"), {"frames": "max"}),
    "reload": (ARMS.format("idle"), GUN.format("reloadfromempty"), {"frames": "gun"}),
    "intro": (ARMS.format("intro_classic"), GUN.format("intro"), {"frames": "max"}),
    # Meathook: Doom Dark Ages' arms layers for it are empty. Until they are replaced, the hook clips are a
    # short hold of the idle pose so the game never lacks a clip (the pull itself is the mod's own code).
    "hook_shoot": (ARMS.format("idle"), GUN.format("idle_pose_meathook"), {"frames": 8}),
    "hook_retract": (ARMS.format("idle"), GUN.format("idle_pose_meathook"), {"frames": 8}),
    "hook_notarget": (ARMS.format("idle"), GUN.format("idle_pose_meathook"), {"frames": 8}),
    "hook_notarget_base": (ARMS.format("idle"), GUN.format("idle_pose_meathook"), {"frames": 8}),
}

# View transform: Doom (X fwd, Y left, Z up, cm) -> view (x right, y up, z fwd, m).
V = np.array([[0, -1, 0, 0], [0, 0, 1, 0], [1, 0, 0, 0], [0, 0, 0, 1]], dtype=np.float64)
V[:3, :3] *= 0.01


# ------------------------------------------------------------------------------------------- math
def quat_to_mat(q):
    x, y, z, w = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def trs(t, q):
    m = np.eye(4)
    m[:3, :3] = quat_to_mat(q)
    m[:3, 3] = t
    return m


def slerp(a, b, t):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    d = np.dot(a, b)
    if d < 0:
        b, d = -b, -d
    if d > 0.9995:
        r = a + (b - a) * t
        return r / np.linalg.norm(r)
    th = np.arccos(d)
    return (np.sin((1 - t) * th) * a + np.sin(t * th) * b) / np.sin(th)


def globals_from_local(parents, local_mats):
    g = [None] * len(parents)
    for i, p in enumerate(parents):
        g[i] = local_mats[i] if p < 0 else g[p] @ local_mats[i]
    return g


# ------------------------------------------------------------------------------------------- files
def roots():
    env = os.environ.get("DOOMRING_DA_EXPORT")
    if env:
        return [Path(p) for p in env.replace(";", os.pathsep).split(os.pathsep) if p]
    out = []
    for c in (REPO.parent, REPO.parent.parent, Path("H:/SteamLibrary/steamapps/common/DOOMTheDarkAges")):
        if (c / "exported_files").exists() or (c / "serrat_export").exists():
            out.append(c)
    return out


def find(rel):
    """First existing exported_files/<rel> or serrat_export/<rel> under the search roots."""
    for r in roots():
        for sub in ("exported_files", "serrat_export"):
            p = r / sub / rel
            if p.exists() and p.stat().st_size > 400:     # 176-byte Cast files are empty placeholders
                return p
    return None


def load_model(rel):
    p = find(rel)
    if p is None:
        raise FileNotFoundError(f"{rel} not found under {[str(r) for r in roots()]}")
    for root in cast.Cast.load(str(p)).Roots():
        for m in root.ChildrenOfType(cast.Model):
            return m, p
    raise RuntimeError(f"no model in {p}")


def skeleton(model):
    bones = model.Skeleton().Bones()
    return ([b.Name() for b in bones], [b.ParentIndex() for b in bones],
            [(np.array(b.LocalPosition(), float), np.array(b.LocalRotation(), float)) for b in bones])


class Clip:
    """One Cast animation: per bone and property (rq, tx, ty, tz) keys (frames, values, mode)."""

    def __init__(self, rel):
        self.curves, self.frames, self.fps = {}, 1, 30.0
        p = find(rel + ".cast") if rel else None
        if p is None:
            return
        for root in cast.Cast.load(str(p)).Roots():
            for a in root.ChildrenOfType(cast.Animation):
                self.fps = a.Framerate() or 30.0
                for cv in a.Curves():
                    kb = [int(x) for x in cv.KeyFrameBuffer()]
                    kv = list(cv.KeyValueBuffer())
                    if cv.KeyPropertyName() == "rq":
                        kv = [tuple(kv[i:i + 4]) for i in range(0, len(kv), 4)]
                    self.curves.setdefault(cv.NodeName(), {})[cv.KeyPropertyName()] = (kb, kv, cv.Mode())
                    if kb:
                        self.frames = max(self.frames, max(kb) + 1)

    def sample(self, bone, prop, frame):
        c = self.curves.get(bone, {}).get(prop)
        if not c:
            return None
        kb, kv, _ = c
        if len(kb) == 1 or frame <= kb[0]:
            return kv[0]
        if frame >= kb[-1]:
            return kv[-1]
        for i in range(len(kb) - 1):
            if kb[i] <= frame <= kb[i + 1]:
                t = (frame - kb[i]) / max(kb[i + 1] - kb[i], 1e-6)
                a, b = kv[i], kv[i + 1]
                if prop == "rq":
                    return tuple(slerp(a, b, t))
                return a + (b - a) * t
        return kv[-1]

    def local(self, names, bind_local, frame):
        out = []
        for i, n in enumerate(names):
            t, q = bind_local[i]
            t, q = t.copy(), np.array(q, float)
            rq = self.sample(n, "rq", frame)
            if rq is not None:
                q = np.array(rq, float)
            for k, axis in (("tx", 0), ("ty", 1), ("tz", 2)):
                v = self.sample(n, k, frame)
                if v is not None:
                    t[axis] = v
            out.append(trs(t, q))
        return out


def mesh_arrays(m):
    pos = np.array(m.VertexPositionBuffer(), np.float32).reshape(-1, 3)
    nrm = np.array(m.VertexNormalBuffer(), np.float32).reshape(-1, 3)
    uv = np.array(m.VertexUVLayerBuffer(0), np.float32).reshape(-1, 2)
    inf = m.MaximumWeightInfluence()
    n = len(pos)
    bi = np.zeros((n, 4), np.uint16)
    bw = np.zeros((n, 4), np.float32)
    if inf > 0:
        ib = np.array(m.VertexWeightBoneBuffer(), np.int64).reshape(n, inf)
        wb = np.array(m.VertexWeightValueBuffer(), np.float32).reshape(n, inf)
        k = min(inf, 4)
        bi[:, :k] = ib[:, :k]
        bw[:, :k] = wb[:, :k]
        s = bw.sum(1, keepdims=True)
        s[s == 0] = 1
        bw /= s
    else:
        bw[:, 0] = 1
    return pos, nrm, uv, bi, bw, np.array(m.FaceBuffer(), np.uint32).reshape(-1, 3)


def material_name(m):
    mat = m.Material()
    return mat.Name().split("/")[-1] if mat else "none"


def material_path(m):
    mat = m.Material()
    return mat.Name() if mat else ""


# ---------------------------------------------------------------------------------- mesh selection
def arm_side(mesh, bone_names):
    """-1 left / +1 right / 0 not an arm: by the share of arm and hand bone weight and the bone suffix."""
    p, n, uv, bi, bw, f = mesh_arrays(mesh)
    arm = left = right = total = 0.0
    for k in range(4):
        for b, w in zip(bi[:, k], bw[:, k]):
            name = bone_names[b]
            total += w
            if any(s in name for s in ("arm_", "thumb", "index", "middle", "ring", "pinky", "armcuff", "roll")) \
                    and not name.startswith("leg") and "leg_" not in name:
                arm += w
                if name.endswith("_lf"):
                    left += w
                elif name.endswith("_rt"):
                    right += w
    if total == 0 or arm / total < 0.9:
        return 0
    return -1 if left > right else 1


def is_ssg_part(mesh):
    path = material_path(mesh).lower()
    return "supershotgun/ssg_" in path and "/upgrades/" not in path


# ------------------------------------------------------------------------------------------- bake
def build_palettes(a_names, a_par, a_bind, g_names, g_par, g_bind, ac, gc, frames):
    a_bind_g = globals_from_local(a_par, [trs(t, q) for t, q in a_bind])
    a_inv = [np.linalg.inv(g) for g in a_bind_g]
    g_bind_g = globals_from_local(g_par, [trs(t, q) for t, q in g_bind])
    g_inv = [np.linalg.inv(g) for g in g_bind_g]
    cam_i, attach_i = a_names.index(CAMERA_BONE), a_names.index(ATTACH_BONE)
    pal_a = np.zeros((frames, len(a_names), 3, 4), np.float32)
    pal_g = np.zeros((frames, len(g_names), 3, 4), np.float32)
    for fr in range(frames):
        ag = globals_from_local(a_par, ac.local(a_names, a_bind, min(fr, ac.frames - 1)))
        view = V @ np.linalg.inv(ag[cam_i])
        for i in range(len(a_names)):
            pal_a[fr, i] = (view @ ag[i] @ a_inv[i])[:3]
        gg = globals_from_local(g_par, gc.local(g_names, g_bind, min(fr, gc.frames - 1)))
        for i in range(len(g_names)):
            pal_g[fr, i] = (view @ ag[attach_i] @ gg[i] @ g_inv[i])[:3]
    return pal_a, pal_g, g_bind_g


def skin(mesh_tuple, pal):
    """Skinned vertex positions (metres, view space) of one baked mesh for one frame palette."""
    _part, _mat, p, n, uv, bi, bw, f = mesh_tuple
    ph = np.concatenate([p, np.ones((len(p), 1), np.float32)], 1)
    out = np.zeros((len(p), 3), np.float64)
    for k in range(4):
        out += bw[:, k:k + 1] * np.einsum("nij,nj->ni", pal[bi[:, k]], ph)
    return out


def bake(preview=None):
    arms, arms_path = load_model(ARMS_MODEL)
    gun, gun_path = load_model(GUN_MODEL)
    a_names, a_par, a_bind = skeleton(arms)
    g_names, g_par, g_bind = skeleton(gun)
    for need in (ATTACH_BONE, CAMERA_BONE):
        if need not in a_names:
            raise RuntimeError(f"arms model has no bone {need}")
    out = OUT_ROOT / NAME
    out.mkdir(parents=True, exist_ok=True)

    # ---- meshes: arms (right then left) and the Super Shotgun's own parts
    meshes = []
    for m in arms.Meshes():
        side = arm_side(m, a_names)
        if not side:
            continue
        p, n, uv, bi, bw, f = mesh_arrays(m)
        meshes.append(("arms", f"{material_name(m)}_{'right' if side > 0 else 'left'}", p, n, uv, bi, bw, f))
    n_arms = len(meshes)
    for m in gun.Meshes():
        if is_ssg_part(m):
            p, n, uv, bi, bw, f = mesh_arrays(m)
            meshes.append(("gun", material_name(m), p, n, uv, bi, bw, f))
    print(f"  {n_arms} arm meshes, {len(meshes) - n_arms} gun meshes")

    # ---- clips
    clips = []
    for clip, (arms_rel, gun_rel, opt) in CLIPS.items():
        ac = Clip(f"{CORE}/{arms_rel}")
        gc = Clip(f"{CORE}/{gun_rel}")
        if not ac.curves:
            print(f"  (no arms clip for {clip}: {arms_rel})")
            continue
        if not gc.curves:
            print(f"  (no gun clip for {clip}: {gun_rel}, gun stays in bind pose)")
        mode = opt.get("frames")
        frames = (max(ac.frames, gc.frames) if mode == "max" else gc.frames if mode == "gun"
                  else mode if isinstance(mode, int) else ac.frames)
        pal_a, pal_g, g_bind_g = build_palettes(a_names, a_par, a_bind, g_names, g_par, g_bind, ac, gc, max(frames, 1))
        clips.append((clip, ac.fps, pal_a, pal_g))
        print(f"  clip {clip}: {len(pal_a)} frames")

    # ---- model.bin (DVM1, as convert_weapon.py writes it)
    with open(out / "model.bin", "wb") as fh:
        fh.write(b"DVM1")
        fh.write(struct.pack("<III", len(a_names), len(g_names), len(meshes)))
        for part, mat, p, n, uv, bi, bw, f in meshes:
            mb = mat.encode()
            fh.write(struct.pack("<BH", 0 if part == "arms" else 1, len(mb)) + mb)
            fh.write(struct.pack("<II", len(p), len(f)))
            verts = np.zeros(len(p), dtype=[("p", "<f4", 3), ("n", "<f4", 3), ("uv", "<f4", 2),
                                            ("bi", "<u2", 4), ("bw", "<f4", 4)])
            verts["p"], verts["n"], verts["uv"], verts["bi"], verts["bw"] = p, n, uv, bi, bw
            fh.write(verts.tobytes())
            fh.write(f.astype("<u4").tobytes())
        fh.write(struct.pack("<I", len(clips)))
        for clip, fps, pa, pg in clips:
            cb = clip.encode()
            fh.write(struct.pack("<H", len(cb)) + cb)
            fh.write(struct.pack("<fI", fps, pa.shape[0]))
            fh.write(pa.astype("<f4").tobytes())
            fh.write(pg.astype("<f4").tobytes())

    # ---- textures: <material>[_n|_s|_e|_g|_pm].png from the exports' _images folders. The mod picks arm sides by
    # a _left / _right material suffix, so the arm textures are also written under those names.
    copied = []
    img_dirs = [p.parent / "_images" for p in (gun_path, arms_path)]
    for r in roots():
        img_dirs += [d for d in r.rglob("_images") if d.is_dir()]
    mats = sorted({m[1] for m in meshes})
    for mat in mats:
        base = mat[:-5] if mat.endswith("_left") else mat[:-6] if mat.endswith("_right") else mat
        for suffix in ("", "_n", "_s", "_e", "_g", "_pm"):
            for d in img_dirs:
                src = d / f"{base}{suffix}.png"
                if src.exists():
                    shutil.copy(src, out / f"{mat}{suffix}.png")
                    copied.append(f"{mat}{suffix}.png")
                    break
    if not copied:
        print("  !! no textures found: export the gun and arms textures (the _images folders) with Serrat")

    # ---- info.json: muzzle estimated at the barrel tips (Eternal reads Doom's md6def tag; Dark Ages has none yet)
    gun_pts = np.vstack([m[2] for m in meshes if m[0] == "gun"])
    tip = gun_pts[gun_pts[:, 0] >= gun_pts[:, 0].max() - 1.0].mean(0)
    info = {"materials": mats, "textures": copied, "clips": [c[0] for c in clips],
            "arms_bones": len(a_names), "gun_bones": len(g_names),
            "muzzle": {"bone": 0, "pos": tip.tolist(), "dir": (tip + np.array([10.0, 0.0, 0.0])).tolist(),
                       "tag": "estimated"}}
    (out / "info.json").write_text(json.dumps(info, indent=1))
    print(f"{NAME}: {len(meshes)} meshes, {len(clips)} clips, {len(copied)} textures -> {out}")

    if preview:
        render_preview(meshes, clips, preview)


# --------------------------------------------------------------------------------------- preview
def render_preview(meshes, clips, path):
    """A picture of the baked pose as the player's camera sees it (and from the side) - to check the pose by eye."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.collections import PolyCollection

    shots = [("idle", 0), ("fire", 3), ("fire", 20), ("reload", 22)]
    shots = [(c, f) for c, f in shots if any(x[0] == c for x in clips)]
    fig, axes = plt.subplots(2, len(shots), figsize=(4.2 * len(shots), 8.4))
    axes = np.array(axes).reshape(2, len(shots))
    for col, (cname, fr) in enumerate(shots):
        _, _, pa, pg = next(x for x in clips if x[0] == cname)
        fr = min(fr, len(pa) - 1)
        for row in range(2):
            ax = axes[row, col]
            polys, colors, depth = [], [], []
            for mt in meshes:
                pts = skin(mt, pa[fr] if mt[0] == "arms" else pg[fr])
                tri = mt[7]
                if len(tri) > 6000:
                    tri = tri[:: len(tri) // 6000 + 1]
                P = pts[tri]
                if row == 0:                                  # the player's view (perspective)
                    z = np.maximum(P[:, :, 2], 0.05)
                    xy = np.stack([P[:, :, 0] / z, P[:, :, 1] / z], -1)
                else:                                         # from the right side: z forward, y up
                    xy = np.stack([P[:, :, 2], P[:, :, 1]], -1)
                n = np.cross(P[:, 1] - P[:, 0], P[:, 2] - P[:, 0])
                n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-9)
                shade = 0.35 + 0.65 * np.abs(n[:, 2] if row == 0 else n[:, 0])
                base = np.array([0.85, 0.62, 0.5]) if mt[0] == "arms" else np.array([0.55, 0.58, 0.65])
                polys.append(xy)
                colors.append(np.clip(base[None] * shade[:, None], 0, 1))
                depth.append(P[:, :, 2 if row == 0 else 0].mean(1))
            polys, colors, depth = np.concatenate(polys), np.concatenate(colors), np.concatenate(depth)
            order = np.argsort(-depth) if row == 0 else np.argsort(depth)
            ax.add_collection(PolyCollection(polys[order], facecolors=colors[order], edgecolors="none"))
            if row == 0:
                ax.set_xlim(-1.0, 1.0)
                ax.set_ylim(-1.0, 0.6)
            else:
                ax.set_xlim(-0.2, 1.0)
                ax.set_ylim(-0.7, 0.5)
            ax.set_aspect("equal")
            ax.set_title(f"{cname} frame {fr}" + (" (camera view)" if row == 0 else " (side view)"), fontsize=9)
    fig.tight_layout()
    fig.savefig(path, dpi=80)
    print("preview ->", path)


if __name__ == "__main__":
    prev = sys.argv[sys.argv.index("--preview") + 1] if "--preview" in sys.argv else None
    bake(prev)
